# 2025-01-09T12:14:33.790922100
import vitis

client = vitis.create_client()
client.set_workspace(path="C:/B_Git/MCS/Drivers/CAN_Test/Vitis")

platform = client.get_component(name="platform")
status = platform.build()

comp = client.get_component(name="app")
comp.build()

