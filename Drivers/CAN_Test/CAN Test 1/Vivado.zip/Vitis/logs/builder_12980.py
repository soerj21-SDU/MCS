# 2025-01-09T15:21:28.966747200
import vitis

client = vitis.create_client()
client.set_workspace(path="C:/B_Git/MCS/Drivers/CAN_Test/Vitis")

platform = client.get_component(name="platform")
status = platform.build()

status = platform.build()

comp = client.get_component(name="app")
comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

