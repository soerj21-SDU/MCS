# 2025-01-10T13:50:11.690099100
import vitis

client = vitis.create_client()
client.set_workspace(path="C:/B_Git/MCS/Drivers/CAN_Test/Vitis")

platform = client.get_component(name="platform")
status = platform.build()

comp = client.get_component(name="app")
comp.build()

domain = platform.get_domain(name="standalone_ps7_cortexa9_0")

status = domain.set_lib(lib_name="xilflash", path="C:/Vitis/2024.1/data/embeddedsw/lib/sw_services/xilflash_v4_11")

status = domain.set_lib(lib_name="libmetal", path="C:/Vitis/2024.1/data/embeddedsw/ThirdParty/sw_services/libmetal_v2_7")

status = domain.set_config(option = "os", param = "standalone_stdout", value = "ps7_uart_0")

status = domain.set_config(option = "os", param = "standalone_stdin", value = "ps7_uart_0")

status = platform.build()

comp.build()

status = platform.build()

status = platform.build()

comp.build()

status = domain.set_lib(lib_name="libmetal", path="C:/Vitis/2024.1/data/embeddedsw/ThirdParty/sw_services/libmetal_v2_7")

status = domain.regenerate()

status = platform.build()

status = platform.build()

comp.build()

domain = platform.get_domain(name="zynq_fsbl")

status = domain.set_config(option = "os", param = "standalone_stdin", value = "ps7_uart_0")

status = domain.set_config(option = "os", param = "standalone_stdout", value = "ps7_uart_0")

status = domain.regenerate()

status = platform.build()

status = platform.build()

comp.build()

vitis.dispose()

vitis.dispose()

