# 2025-01-09T11:33:31.164873400
import vitis

client = vitis.create_client()
client.set_workspace(path="C:/B_Git/MCS/Drivers/CAN_Test/Vitis")

platform = client.create_platform_component(name = "platform",hw_design = "C:/B_Git/MCS/Drivers/CAN_Test/Vitis/design_1_wrapper.xsa",os = "standalone",cpu = "ps7_cortexa9_0",domain_name = "standalone_ps7_cortexa9_0")

platform = client.get_component(name="platform")
status = platform.build()

comp = client.create_app_component(name="application",platform = "C:/B_Git/MCS/Drivers/CAN_Test/Vitis/platform/export/platform/platform.xpfm",domain = "standalone_ps7_cortexa9_0")

domain = platform.get_domain(name="zynq_fsbl")

status = domain.set_lib(lib_name="xilflash", path="C:/Vitis/2024.1/data/embeddedsw/lib/sw_services/xilflash_v4_11")

status = platform.build()

comp = client.get_component(name="application")
comp.build()

client.delete_component(name="application")

comp = client.create_app_component(name="app",platform = "C:/B_Git/MCS/Drivers/CAN_Test/Vitis/platform/export/platform/platform.xpfm",domain = "standalone_ps7_cortexa9_0",template = "hello_world")

status = platform.build()

comp = client.get_component(name="app")
comp.build()

status = platform.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

