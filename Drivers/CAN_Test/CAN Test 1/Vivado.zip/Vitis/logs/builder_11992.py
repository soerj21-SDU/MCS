# 2025-01-09T11:56:09.413938900
import vitis

client = vitis.create_client()
client.set_workspace(path="C:/B_Git/MCS/Drivers/CAN_Test/Vitis")

vitis.dispose()

