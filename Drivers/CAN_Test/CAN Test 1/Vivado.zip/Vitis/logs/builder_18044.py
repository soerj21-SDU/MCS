# 2025-01-09T13:33:21.604471
import vitis

client = vitis.create_client()
client.set_workspace(path="C:/B_Git/MCS/Drivers/CAN_Test/Vitis")

platform = client.get_component(name="platform")
status = platform.update_hw(hw_design = "C:/B_Git/MCS/Drivers/CAN_Test/Vitis/HW_export.xsa")

status = platform.build()

status = platform.build()

comp = client.get_component(name="app")
comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.update_hw(hw_design = "C:/B_Git/MCS/Drivers/CAN_Test/Vitis/HW_working.xsa")

status = platform.build()

status = platform.build()

comp.build()

status = platform.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

status = platform.build()

comp.build()

vitis.dispose()

