function TraceInfoFlag() {
    this.traceFlag = new Array();
    this.traceFlag["stateflow_test.c:48c31"]=1;
    this.traceFlag["stateflow_test.c:51c31"]=1;
    this.traceFlag["stateflow_test.c:52c21"]=1;
    this.traceFlag["stateflow_test.c:63c21"]=1;
}
top.TraceInfoFlag.instance = new TraceInfoFlag();
function TraceInfoLineFlag() {
    this.lineTraceFlag = new Array();
    this.lineTraceFlag["stateflow_test.c:48"]=1;
    this.lineTraceFlag["stateflow_test.c:49"]=1;
    this.lineTraceFlag["stateflow_test.c:50"]=1;
    this.lineTraceFlag["stateflow_test.c:51"]=1;
    this.lineTraceFlag["stateflow_test.c:52"]=1;
    this.lineTraceFlag["stateflow_test.c:53"]=1;
    this.lineTraceFlag["stateflow_test.c:56"]=1;
    this.lineTraceFlag["stateflow_test.c:59"]=1;
    this.lineTraceFlag["stateflow_test.c:63"]=1;
    this.lineTraceFlag["stateflow_test.c:64"]=1;
    this.lineTraceFlag["stateflow_test.c:67"]=1;
    this.lineTraceFlag["stateflow_test.c:70"]=1;
    this.lineTraceFlag["stateflow_test.h:44"]=1;
    this.lineTraceFlag["stateflow_test.h:45"]=1;
    this.lineTraceFlag["stateflow_test.h:50"]=1;
    this.lineTraceFlag["stateflow_test.h:55"]=1;
    this.lineTraceFlag["stateflow_test.h:56"]=1;
}
top.TraceInfoLineFlag.instance = new TraceInfoLineFlag();
