/*
 * gloal_def.h
 *
 *  Created on: Mar 25, 2020
 *      Author: soeren
 *
 *  Describtion:
 *  This module(h and c file) holds all the global variables for the system.
 */

#ifndef SRC_GLOBAL_DEF_H_
#define SRC_GLOBAL_DEF_H_

#include "os.h"
#include "ucos_bsp.h"
#include "stdint.h"
#include "stdbool.h"

// Defines :

#define DEBUG 0  // Enable for debug.
#define UNIT_TESTS 0 // Run UNIT TESTS
#define CELL_SIMULATION 0 // CELL simulation instead of cell com

/// Physical values
#define MIN_CELL_VOLTAGE 3000 //Unit mv
#define MAX_CELL_VOLTAGE 4100 // Unit mv
#define VOLT_MAX 4170 // Unit mV
#define VOLT_CHARGE_LIMIT 4100 // Unit mV
#define VOLT_CHARGE_GOAL 4050 // Unit mV
#define VOLT_NOMINAL 3700 // Unit mV
#define VOLT_MIN 3030 // Unit mV
#define BATTERYTASK_LOOP_TIME_TICKS 50 //ms




#define MAX_NUMBER_OF_BANKS 5
#define NUMBER_OF_CELLS_PR_BANK 28
// The number of devices per bank.
#define DEVICES_PR_BANK 2
#define NUMBER_OF_CELL_TEMPS_PR_BANK 10
#define NUMBER_OF_DISCHARGE_TEMPS_PR_BANK 14
#define NUMBER_OF_TEMPS_PER_DEVICE 5

// Communication


// CAN INTERFACE
#define CAN_BASEADDR 0x400



// NOT YET PUT IN A CATEGORY
#define DEFAULT_BANK_COUNT 1



#endif /* SRC_GLOBAL_DEF_H_ */
