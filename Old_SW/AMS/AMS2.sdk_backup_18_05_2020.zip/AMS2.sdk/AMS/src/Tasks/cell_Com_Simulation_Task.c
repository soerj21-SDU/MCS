/*
 * cell_Com_Simulation_Task.c
 *
 *  Created on: Apr 8, 2020
 *      Author: soeren
 */

#include "cell_Com_Simulation_Task.h"

#include <stdlib.h>
#include <stdio.h>
#include "lib_math.h"


OS_ERR cellComSim_CreateTask()
{
	OS_ERR error;

    OSTaskCreate(&g_cell_com_simulation_TCP,                      //  - Cell com Simulation Task.
                 "Cell_COM Simulation Task",
				 CellComSim_Task,
				 0,          				//argument for task. None for the moment
				 CELL_COM_SIMULATION_TASK_PRIO,
				 &cell_com_simulation_task_stk[0],
				 CELL_COM_SIMULATION_TASK_STK_SIZE/10,
				 CELL_COM_SIMULATION_TASK_STK_SIZE,
				 CELL_COM_SIMULATION_TASK_MSGQ_SIZE,
				 0,
				 DEF_NULL,
				 (OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR), //stack checking and stack clearing options
				 &error);

    return error;

}
void CellComSim_Task(void *arg)
{
	OS_ERR err;
	Math_Init();
	while(1)
	{

		g_CAN_TX_Alive_Counter++;

		uint16_t random_16;

		//extern uint16_t g_cell_voltages[5][28];

		/*
		uint8_t number_of_banks=5;
		uint8_t cell_pr_bank=28;
		for(uint8_t i = 0; i <number_of_banks ; i++)
		{
			for(uint8_t j = 0; j <cell_pr_bank ; j++)
			{
				random_16= ((uint16_t) Math_Rand() &65000);
			g_cell_voltages[i][j]=random_16;
			}
		}
		*/

		/*
		// Fixed values
		for(uint8_t bank=0;bank <=4;bank++)
		{
			for(uint8_t cell=0; cell<28; cell++)
			{
				g_cell_voltages[bank][cell]=bank*28+cell;
			}
		}
		// Fixed values end
		 *
		 */

		g_higest_cell_temperature = (uint8_t) Math_Rand();
		g_lowest_cell_voltage = ((uint16_t) Math_Rand() &511);
		g_SOC =(((uint8_t) Math_Rand())>>1);

		OSTimeDlyHMSM(0,0,0,500,OS_OPT_TIME_HMSM_STRICT,&err); // delay 2 sec

	}
}


