/*
 * test_Task.c
 *
 *  Created on: Mar 18, 2020
 *      Author: soeren
 */

#include "controller_Task.h"

#include "../matlat_import/contoller/control_statemachine.h"
#include "os.h"
#include "../utility/relay.h"
#include "../utility/shutdown.h"

#include "../global_def.h"

OS_ERR create_controller_task()
{
	OS_ERR err;

    OSTaskCreate(&Test_TCB,
                 "State machine test Task",
				 controller_task,
				 0,          				//argument for task. None for the moment
				 TEST_TASK_PRIO,
				 &Test_TaskStk[0],
				 TEST_TASK_STK_SIZE/10,
				 TEST_TASK_STK_SIZE,
				 TEST_TASK_MSGQ_SIZE,
				 0,
				 DEF_NULL,
				 (OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR), //stack checking and stack clearing options
				 &err);

    return err;

}
void controller_task(void *arg){

	//UCOS_Printf("Test task started \r\n");

	// Local instance of Model
	RT_MODEL controller_instance;
	ExtU controller_input;
	ExtY controller_output;

	Controller_statemachine_initialize(&controller_instance);


	OS_ERR os_err;
	while(1)
	{
		OSTimeDlyHMSM(0,0,0,20,OS_OPT_TIME_HMSM_STRICT,&os_err); // delay 10ms


		// Mutexes
		OSMutexPend(&g_mutex_status_block,0,OS_OPT_PEND_BLOCKING,0,&os_err);
		OSMutexPend(&g_mutex_TS_block,0,OS_OPT_PEND_BLOCKING,0,&os_err);

		// Prepare inputs
		controller_input.AIR_p_AUX = AIRP_AUX();
		controller_input.AIR_m_AUX= AIRM_AUX();
		controller_input.PRE_AUX=Precharge_AUX();
		controller_input.SC_END = SC_END();
		controller_input.command = command_signal;
		controller_input.V_BAT = 400; // TEST CONDETIONS
		controller_input.V_TS = 400;
		controller_input.TS_Current = 0;
		controller_input.AMS_lached= AMS_Latched();
		

		Controller_statemachine_step(&controller_instance,&controller_input,&controller_output);

		//Decode output:

		AIRM_Control(controller_output.AIR_m_CTRL);
		AIRP_Control(controller_output.AIR_p_CTRL);
		Precharge_Control(controller_output.Pre_CTRL);
		EN_SC(controller_output.SC_Enable);
		AMS_SC(controller_output.AMS_Error_CTRL);
		Control_Errors=controller_output.Error_code;
		g_charge_current = controller_output.Charger_current;


		OSTaskQPost(&CAN_TX_TCB,
				&Control_Errors,
				sizeof(Control_Errors),
				OS_OPT_POST_FIFO,
				&os_err);



		OSMutexPost(&g_mutex_TS_block,OS_OPT_POST_NONE,&os_err);
		OSMutexPost(&g_mutex_status_block,OS_OPT_POST_NONE,&os_err);
		//controller_input.command



	}






















	/*
	// local instances of Model
	RT_MODEL char_instance;
	boolean_T _sc_end;
	boolean_T _sc_enable;
	uint8_t _cmd_flag;
	boolean_T event_flag;




	  Chart_initialize(&char_instance,&_cmd_flag,&_sc_end,&_sc_enable,&event_flag);

	OS_ERR err;
	while(1)
	{


		OSTimeDlyHMSM(0,0,0,100,OS_OPT_TIME_HMSM_STRICT,&err); // delay 10ms
			AMS_SC(false);

			//Setting up input data for Chart

			_cmd_flag = cmd_flags;
			_sc_end = SC_END();

			 Chart_step(&char_instance,_cmd_flag,_sc_end,&_sc_enable,&event_flag);

			EN_SC(_sc_enable);
			AIRP_Control(AIR_OUT);
			Error_SC_Event = event_flag;





	}
	*/
}



