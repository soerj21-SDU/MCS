/*
 * monitor_Task.c
 *
 *  Created on: Apr 8, 2020
 *      Author: soeren
 */

#include "monitor_Task.h"


OS_ERR create_monitor_Task()
{
	OS_ERR error;

    OSTaskCreate(&g_monitor_TCP,                      //  - RX Task.
                 "CAN RX Task",
				 Monitor_Task,
				 0,          				//argument for task. None for the moment
				 MONITOR_TASK_PRIO,
				 &monitor_task_stk[0],
				 MONITOR_TASK_STK_SIZE/10,
				 MONITOR_TASK_STK_SIZE,
				 MONITORTX_TASK_MSGQ_SIZE,
				 0,
				 DEF_NULL,
				 (OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR), //stack checking and stack clearing options
				 &error);

    return error;




}
void Monitor_Task(void *arg)
{
	OS_ERR os_err;
	OS_TICK last_time_ok;
	OS_TICK now;

	//OS_CFG_TICK_RATE_HZ
	//RTOS_ERR rtos_err;
	 OS_RATE_HZ OS_tick_Hz = OSTimeTickRateHzGet(&os_err);
	// OS_CFG_TICK_RATE_HZ/1000
	while(1)
	{
		 // Suspend untill signal flag is raised.

		// Take cell voltage semaphore
		// Go through each cell voltages
		// Give semaphore

		OSMutexPend(&g_mutex_cell_voltages,0,OS_OPT_PEND_BLOCKING,0,&os_err);
		if(os_err != OS_ERR_NONE)
		{
			UCOS_Printf("Error Monitor Task : Cell voltage MUTEX error = %d", os_err);
		}

		now = OSTimeGet(&os_err);
		for(uint8_t bank = 0; bank<g_number_of_banks; bank++)
		{
			for(uint8_t cell=0; cell<NUMBER_OF_CELLS_PR_BANK; cell++)
			{
				// Evaluate cell voltage
				if(g_cell_voltages[bank][cell] < MIN_CELL_VOLTAGE) // && NO ERROR
				{
					// Under limit. Do not refresh the last_time_ok
				}
				else
				{
					last_time_ok = now; // refrech time
				}

				if((now+MONITOR_TICK_TIME)-last_time_ok)
				{

				}

			}

		}
		//get_devicenumber(bank number,cell number)



		// Take cell temp semaphore
		// Go through each cell temp
		// Give cell temp semaphore.

	}

}
