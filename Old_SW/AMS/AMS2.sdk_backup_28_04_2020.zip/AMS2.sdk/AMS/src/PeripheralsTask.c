/*
 * PeripheralsTask.c
 *
 *  Created on: 7. maj 2019
 *      Author: matt
 */

#include "PeripheralsTask.h"

#include <Source/os.h>
#include "os.h"
#include "xil_printf.h"
#include "xcanps.h"
#include "stdlib.h"

#include "AMS_cfg.h"
#include "common.h"
#include "dac.h"
#include "relay.h"
#include "shutdown.h"
#include "tmp100.h"

void PeripheralsTask(void *arg)
{
	OS_ERR os_err;

	while (1)
	{
		xil_printf("---\r\n");

		OSMutexPend(&Voltage_Mutex,
				  0,
				  OS_OPT_PEND_BLOCKING,
				  0,
				  &os_err);
		if(os_err != OS_ERR_NONE)
			xil_printf("PeripheralTask take temperature mutex error\r\n");

		xil_printf("Sum of banks = %6dmV\r\n", sum_of_all_cells);

		OSMutexPost(&Voltage_Mutex,
				  OS_OPT_PEND_BLOCKING,
				  &os_err);
		if(os_err != OS_ERR_NONE)
			xil_printf("PeripheralTask give temperature mutex error\r\n");

		for (uint8_t i = 0; i < bank_count; i++)
		{
			xil_printf("\tBANK #%d | Sum of cells in bank = %6dmV\r\n", i+1, cell_bank_volt[i]);

			OSMutexPend(&Voltage_Mutex,
					  0,
					  OS_OPT_PEND_BLOCKING,
					  0,
					  &os_err);
			if(os_err != OS_ERR_NONE)
				xil_printf("PeripheralTask take temperature mutex error\r\n");

			//Print cell voltages in a 4x7 grid
			for (uint8_t j = 0; j < 4; j++)
			{
				for (uint8_t k = 0; k < 7; k++)
				{
					xil_printf("[V#%2d: %4dmV]", j*7+k+1, cell_volt[i][j*7+k]);
				}
				xil_printf("\r\n");
			}

			OSMutexPost(&Voltage_Mutex,
					  OS_OPT_PEND_BLOCKING,
					  &os_err);
			if(os_err != OS_ERR_NONE)
				xil_printf("PeripheralTask give temperature mutex error\r\n");

			OSMutexPend(&Temperature_Mutex,
					  0,
					  OS_OPT_PEND_BLOCKING,
					  0,
					  &os_err);
			if(os_err != OS_ERR_NONE)
				xil_printf("PeripheralTask take voltage mutex error\r\n");

			//Print cell temperatures in a 2x5 grid
			for (uint8_t j = 0; j < 2; j++)
			{
				for (uint8_t k = 0; k < 5; k++)
				{
					xil_printf("[T#%2d: %2d.%1dC]", j*5+k+1, cell_temp[i][j*5+k]/10, abs(cell_temp[i][j*5+k])%10);
				}
				xil_printf("\r\n");
			}

			//Print discharge circuit temperatures in a 2x7 grid
			for (uint8_t j = 0; j < 2; j++)
			{
				for (uint8_t k = 0; k < 7; k++)
				{
					xil_printf("[D#%2d: %2d.%1dC]", j*7+k+1, bal_temp[i][j*7+k]/10, abs(bal_temp[i][j*7+k])%10);
				}
				xil_printf("\r\n");
			}

			OSMutexPost(&Temperature_Mutex,
					  OS_OPT_PEND_BLOCKING,
					  &os_err);
			if(os_err != OS_ERR_NONE)
				xil_printf("PeripheralTask give temperature mutex error\r\n");
		}
		//*/

		//*
		xil_printf("--\r\n");

		xil_printf("IMD_Status = %d | IMD_Latched = %d | IMD_Data = %d | AMS_Latched = %d | SC_IN = %d | SC_HVDC_IL = %d | SC_IN_Again = %d | SC_END = %d\r\n",
					IMD_Status(), IMD_Latched(), IMD_Data(), AMS_Latched(), SC_IN(), SC_HVDC_IL(), SC_IN_Again(), SC_END());

		xil_printf("AIRM_AUX = %d | AIRP_AUX = %d | Precharge_AUX = %d\r\n",
					AIRM_AUX(), AIRP_AUX(), Precharge_AUX());
		//*/

		xil_printf("CPU load = %02d.%02d%%\r\n", OSStatTaskCPUUsage/100, OSStatTaskCPUUsage%100);

		//xil_printf("Ambient temperature = %d C\r\n", master_temp);

		//xil_printf("Charging scaler = %d%%\r\n", charging_scaler);

		//*
		OSMutexPend(&Power_Mutex,
				  0,
				  OS_OPT_PEND_BLOCKING,
				  0,
				  &os_err);
		if(os_err != OS_ERR_NONE)
			xil_printf("PeripheralTask take power mutex error\r\n");

		xil_printf("Shunt battery voltage: %d mV\r\n", shunt_battery_volt);
		xil_printf("Shunt precharge voltage: %d mV\r\n", shunt_precharge_volt);

		xil_printf("Shunt current: %d mA\r\n", shunt_curr);
		xil_printf("Shunt power: %d W\r\n", shunt_power);

		xil_printf("Shunt coulomb counter: %d As\r\n", shunt_coulomb_counter);
		xil_printf("Shunt energy counter: %d Wh\r\n", shunt_energy_counter);

		OSMutexPost(&Power_Mutex,
				  OS_OPT_PEND_BLOCKING,
				  &os_err);
		if(os_err != OS_ERR_NONE)
			xil_printf("PeripheralTask give power mutex error\r\n");
		//*/

		OSTimeDly(PERIPHERALSTASK_LOOP_TIME_TICKS,
				  OS_OPT_TIME_PERIODIC,
				  &os_err);
		if(os_err != OS_ERR_NONE)
			xil_printf("PeripheralsTask delay error\r\n");
	}
}
