/*
 * BatteryTask.h
 *
 *  Created on: 6. maj 2019
 *      Author: matt
 */

#ifndef BATTERYTASK_H_
#define BATTERYTASK_H_

void BatteryTask(void *arg);

#endif /* BATTERYTASK_H_ */
