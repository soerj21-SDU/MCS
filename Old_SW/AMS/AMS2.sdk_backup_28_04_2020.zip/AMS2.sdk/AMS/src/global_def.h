/*
 * gloal_def.h
 *
 *  Created on: Mar 25, 2020
 *      Author: soeren
 *
 *  Describtion:
 *  This module(h and c file) holds all the global variables for the system.
 */

#ifndef SRC_GLOBAL_DEF_H_
#define SRC_GLOBAL_DEF_H_

#include "os.h"
#include "ucos_bsp.h"
#include "stdint.h"
#include "stdbool.h"

// Defines :

#define DEBUG 0  // Enable for debug.
#define UNIT_TESTS 0 // Run UNIT TESTS
#define CELL_SIMULATION 1 // CELL simulation instead of cell com

#define MAX_NUMBER_OF_BANKS 5
#define NUMBER_OF_CELLS_PR_BANK 28

// Communication
extern uint8_t command_signal; // Used to transfer command from COM to Control task

// Control Task
#ifndef DEFINED_TYPEDEF_FOR_ControlState_T_
#define DEFINED_TYPEDEF_FOR_ControlState_T_

typedef enum {
  ControlState_T_None = 0,             /* Default value */
  ControlState_T_Init_state,
  ControlState_T_Idle,
  ControlState_T_SC_enable,
  ControlState_T_Error,
  ControlState_T_Error_lached,
  ControlState_T_SC_enabled,
  ControlState_T_Close_AIR_m,
  ControlState_T_Close_Pre,
  ControlState_T_Precharnig,
  ControlState_T_Open_Pre,
  ControlState_T_Close_AIR_p,
  ControlState_T_TS_active,
  ControlState_T_Drive,
  ControlState_T_Init_charing,
  ControlState_T_C_Close_AIR_m,
  ControlState_T_Charger_Error,
  ControlState_T_Charger_Error_lached,
  ControlState_T_C_Close_Pre,
  ControlState_T_C_Precharnig,
  ControlState_T_C_Open_Pre,
  ControlState_T_C_Close_AIR_p,
  ControlState_T_Charge_Algortihm,
  ControlState_T_C_Open_AIR_p,
  ControlState_T_C_Open_AIR_m
} ControlState_T;

#endif

#ifndef DEFINED_TYPEDEF_FOR_e_command_signals_
#define DEFINED_TYPEDEF_FOR_e_command_signals_

typedef enum {
  NON = 0,                             /* Default value */
  ENABLE_SC,
  ACTIVATE_TS,
  DRIVE,
  Charge_Start
} e_command_signals;

#endif

#ifndef DEFINED_TYPEDEF_FOR_e_control_errors_
#define DEFINED_TYPEDEF_FOR_e_control_errors_

typedef enum {
  E_AMS_UNABLE_TO_CLOSE_SC = 0,        /* Default value */
  E_AMS_SC_BROKEN,
  E_AMS_UNABLE_TO_CLOSE_AIR_M,
  E_AMS_UNABLE_TO_CLOSE_PRE,
  E_AMS_UNABLE_TO_CLOSE_AIR_P,
  E_AMS_UNABLE_TO_OPEN_AIR_M,
  E_AMS_UNABLE_TO_OPEN_AIR_P,
  E_AMS_UNABLE_TO_OPEN_PRE,
  E_AMS_PRE_TIMEOUT,
  E_AMS_UNEXCEPTED_TS_CURRENT,
  E_AMS_RELAY_FAIELD,
  E_AMS_UNFIT_CHARGE_VOLTAGE
} e_control_errors;

#endif


extern uint16_t Control_Errors;

extern ControlState_T Control_states;


// TS block
extern double BAT_Voltage;
extern double  TS_Voltage;
extern double  TS_Current;

// Voltage Block
//extern uint16_t g_cell_voltages[5][28];

// Status block
extern double Charge_Current;


// CAN INTERFACE
extern int g_CAN_TX_Alive_Counter;


// NOT YET PUT IN A CATEGORY
extern uint8_t g_number_of_banks; // max 3 bits
extern uint8_t g_bank_count_set_by_Car;
extern bool g_warining_temprature;
extern bool g_warining_voltage_near_limit;



#endif /* SRC_GLOBAL_DEF_H_ */
