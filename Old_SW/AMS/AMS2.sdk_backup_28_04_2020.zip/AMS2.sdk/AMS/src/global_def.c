/*
 * global_def.c
 *
 *  Created on: Mar 25, 2020
 *      Author: soeren
 */

#include "global_def.h"

// Communication
uint8_t command_signal;

// Control Statemachine
uint16_t Control_Errors; // TO DO: Make a single byte.

ControlState_T Control_states;

// TS block
double  BAT_Voltage=0;
double  TS_Voltage=0;
double  TS_Current=0;

// Voltage Block
//uint16_t g_cell_voltages[5][28];

// Status block
double Charge_Current;

int g_CAN_TX_Alive_Counter=0;


// NOT YET PUT IN A CATEGORY
uint8_t g_number_of_banks=1; // max 3 bits
uint8_t g_bank_count_set_by_Car =0;
bool g_warining_temprature=false;
bool g_warining_voltage_near_limit=false;

