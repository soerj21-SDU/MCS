/*
 * common.c
 *
 *  Created on: 21. maj 2019
 *      Author: matt
 *
 *  This file contains declarations of shared variables used throughout the entire project.
 *  The external declarations of these variables are found in "common.h".
 *  Remember to take and give mutexes when using these variables.
 */

#include "common.h"
#include "AMS_cfg.h"


//***********************   Available Mutexes   *******************
OS_MUTEX Power_Mutex;      //
OS_MUTEX SOC_Mutex;
OS_MUTEX Voltage_Mutex;
OS_MUTEX Temperature_Mutex;
OS_MUTEX Controlvariable_Mutex;



//*****************  Controlvariable_Mutex Protected  ****************************
uint8_t bank_count = DEFAULT_BANK_COUNT;
uint8_t status;
uint8_t AMS_flags;
uint8_t rdy_flags;
uint8_t cmd_flags;
int16_t master_temp;
uint8_t sc;
bool Error_SC_Event;
uint8_t charging_scaler = 100;
bool balance_enable = false;
bool bal_enable[5][28];
bool charge_ready;
bool charge_finished;

int debug_bool = false;
enum AMS_State AMS_state = IdleState;

uint16_t error_flags = 0;
bool any_LTC6813_error = false;
bool LTC6813_error[10] = {false};

bool connected_to_charger = false;

//*****************  Voltage_Mutex Protected  ****************************

uint16_t cell_volt[5][28];
OS_TICK cell_volt_ts[5][28];
uint32_t cell_bank_volt[5];
uint32_t sum_of_all_cells;


//*****************  Temperature_Mutex Protected  ****************************
int16_t cell_temp[5][10];
OS_TICK cell_temp_ts[5][10];
OS_TICK cell_charge_temp_ts[5][10];
int16_t bal_temp[5][14];

//*****************  Power_Mutex Protected  ****************************
int32_t shunt_power;
OS_TICK  shunt_power_ts;
int32_t shunt_power_average;
int32_t shunt_curr; // in mA, read from shunt
OS_TICK  shunt_curr_ts;


//*****************  SOC_Mutex Protected  ****************************
uint32_t shunt_battery_volt; // in mV, read from shunt (Voltage Measurement U1)
OS_TICK  shunt_battery_volt_ts;
uint8_t shunt_battery_volt_updated;
uint32_t shunt_precharge_volt; // in mV read from shunt (voltage measurement U2)
OS_TICK  shunt_precharge_volt_ts;
uint8_t shunt_precharge_volt_updated;

int32_t shunt_coulomb_counter;
OS_TICK  shunt_coulomb_counter_ts;
int32_t shunt_energy_counter;
OS_TICK  shunt_energy_counter_ts;


