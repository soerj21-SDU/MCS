/*
 * tmp100.h
 *
 *  Created on: 14. maj 2019
 *      Author: matt
 */

#ifndef TMP100_H_
#define TMP100_H_

#include "stdint.h"

void tmp100_init();

int16_t tmp100_read();

#endif /* TMP100_H_ */
