/*****************************************************************************
* University of Southern Denmark
* Embedded Programming (EMP)
*
* MODULENAME.:CanFunctions
*
* PROJECT....:Accumulator Management System
*
* DESCRIPTION: Holds tasks and setup related to Can communication.
*
* Change Log:
******************************************************************************
* Date    Id    Change
* YYMMDD: 190405
* --------------------
*
*
*****************************************************************************/
#ifndef SRC_CANFUNCTIONS_H_
#define SRC_CANFUNCTIONS_H_
/***************************** Include files *******************************/
//#include <stdio.h>
#include <stdlib.h>
#include <app_cfg.h>
#include <can_cfg.h>
#include <can_bsp.h>
#include "can_sig.h"
#include "can_msg.h"
#include "can_err.h"
#include "drv_can.h"
//#include "cpu.h"
//#include "AMSControl.h"
#include  <can_frm.h>
#include  <can_bus.h>

#include <stdio.h>
#include "common.h"
#include "math.h"
/*****************************    Defines    *******************************/
/*
#define  CAN0_RX_TASK_PRIO                         10u
#define  CAN0_TX_TASK_PRIO                         11u
#define  CAN0_RX_TASK_STK_SIZE                     512u
#define  CAN0_TX_TASK_STK_SIZE                	   512u
#define  CAN0_RX_TASK_MSGQ_SIZE					   32u
#define  CAN0_TX_TASK_MSGQ_SIZE					   32u
*/
#define  CAN_SHUNT_TASK_PRIO                         10u
#define  CAN_SHUNT_TASK_STK_SIZE                     512u
#define  CAN_SHUNT_TASK_MSGQ_SIZE					 32u


#define  CAN1_RX_TASK_PRIO                         9u
#define  CAN1_TX_TASK_PRIO                         10u
#define  CAN1_RX_TASK_STK_SIZE                     512u
#define  CAN1_TX_TASK_STK_SIZE                	   512u
#define  CAN1_RX_TASK_MSGQ_SIZE					   32u
#define  CAN1_TX_TASK_MSGQ_SIZE					   32u
/*****************************   Constants   *******************************/
extern  const CANBUS_PARA  CanCfg0;
extern  const CANBUS_PARA  CanCfg1;

OS_TCB CAN_SHUNT_TCB;
CPU_STK  CAN_SHUNT_TaskStk[CAN_SHUNT_TASK_STK_SIZE];
OS_ERR CAN_SHUNT_ERR;


OS_TCB CAN1_RX_TCB;
OS_TCB CAN1_TX_TCB;
CPU_STK  CAN1_RxTaskStk[CAN1_RX_TASK_STK_SIZE];
CPU_STK  CAN1_TxTaskStk[CAN1_TX_TASK_STK_SIZE];
OS_ERR CAN1_RX_ERR;
OS_ERR CAN1_TX_ERR;

/*****************************   Variables   *******************************/
bool reset_flag;
/*****************************   Functions   *******************************/
void CAN_init(void);
//void CreateTasks();
/******************************************************************************/
#endif /* SRC_CANFUNCTIONS_H_ */
/****************************** End Of Module *******************************/

