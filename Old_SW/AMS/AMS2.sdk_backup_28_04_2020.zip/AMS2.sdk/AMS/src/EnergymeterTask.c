/*
 * EnergymeterTask.c
 *
 *  Created on: 28. jun. 2019
 *      Author: M
 */
#include "EnergymeterTask.h"
#include "stdio.h"

void EnergymeterTask(void* arg)
{//Moving Average. 500 ms window. 100hz sampling. 1000/100 = 10 ms intervals. That means 500/10 = 50. 50 window segments.

	const int window_size = 10;  //  500ms/looptime
	int32_t power_arr[10] = {0}; //array size = window_size
	int power_count = 0;
	shunt_power_average = 0;

	while (1)
	{
		OSMutexPend(&Power_Mutex, 0, OS_OPT_PEND_BLOCKING, 0, &Energymeter_ERR);
		if(Energymeter_ERR != OS_ERR_NONE)
		    { UCOS_Print("Energymeter Mutex Error\n");}

		shunt_power_average -= power_arr[power_count]/window_size;
		power_arr[power_count]=shunt_power;
	    shunt_power_average += power_arr[power_count]/window_size;

/* TEST
	    printf("shunt_power: %ld \n",shunt_power);
	    printf("shunt_power_average: %ld \n", shunt_power_average);
	    shunt_power += 5;
//*/

	    OSMutexPost(&Power_Mutex, OS_OPT_POST_NONE, &Energymeter_ERR);
	    if(Energymeter_ERR != OS_ERR_NONE)
	    {UCOS_Print("Energymeter Mutex Error \n");}

	    power_count++;
	    if(power_count >= window_size)
	    	{power_count = 0;}


		OSTimeDly(50, OS_OPT_TIME_PERIODIC, &Energymeter_ERR); //Delay in number of ticks. periodic.
		if(Energymeter_ERR != OS_ERR_NONE)
			UCOS_Print("Energymeter Delay Error \n");
	}

}

void Energymeter_init()
{
     OSTaskCreate(&Energymeter_TCB,                       //  - TX Task.
                  "Energymeter Task",
				  EnergymeterTask,                       //
 				 0, 						//argument for task. None in this case
				 Energymeter_TASK_PRIO,
 				 &EnergymeterTaskStk[0],
				 Energymeter_TASK_STK_SIZE/10,
				 Energymeter_TASK_STK_SIZE,
				 Energymeter_TASK_MSGQ_SIZE,
 				 0,
 				 DEF_NULL,
 				 (OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
 				 &Energymeter_ERR);
}
