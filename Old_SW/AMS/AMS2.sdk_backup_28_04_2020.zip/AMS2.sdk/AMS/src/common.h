/*
 * common.h
 *
 *  Created on: 21. maj 2019
 *      Author: matt
 */

#ifndef COMMON_H_
#define COMMON_H_

#include "os.h"
#include "ucos_bsp.h"
#include "stdint.h"
#include "stdbool.h"




extern OS_MUTEX Power_Mutex;      //
extern OS_MUTEX SOC_Mutex;
extern OS_MUTEX Voltage_Mutex;
extern OS_MUTEX Temperature_Mutex;
extern OS_MUTEX Controlvariable_Mutex;

//*****************  Controlvariable_Mutex Protected  ****************************
extern bool bal_enable[5][28];
extern bool balance_enable;
extern bool any_LTC6813_error;
extern bool LTC6813_error[10];
// The amount of connected battery banks. Can be changed from the Master Controller. (0-5)
extern uint8_t bank_count;
 // In status and Flags a bit is 1 if variable is true/active. 0 if it is false/off.
extern uint8_t status;        //  bit 7: system error/safety chain, bit 6: balancing, bit 5: charging, bit 4: drive, bit 3: precharge, bit 2 Precharge relay, bit 1: Air+, bit 0: Air-
extern uint8_t AMS_flags;      //bit2: AMS_READY bit1: PRECHARGE_DONE bit0: SC enabled
extern uint8_t rdy_flags;     // bit 7: shunt rdy. bit 6: master rdy to drive. bit 5: Master rdy to charge. bit 4: slave rdy. bit 3: precharge done
extern uint8_t cmd_flags;
extern int16_t master_temp;
extern uint8_t sc;            // safety chain flags.   bit3: SC_ENABLE.  bit2: SC_HVD_INTERLOCK. bit1: SC_AMS_ERROR. bit0: SC_IMD_ERROR
extern uint8_t charging_scaler;
extern bool Error_SC_Event;

extern bool charge_ready; // Enabled by ChargingTask after AMS transition to ChargeState
extern bool charge_finished;
extern int debug_bool;           // Used to toggle console prints
enum AMS_State
{
	IdleState,
	SCEnableRelayState,
	SCEnableState,
	PrechargeRelay1State,
	PrechargeRelay2State,
	PrechargeState,
	PrechargeDoneRelayState,
	PrechargeDoneState,
	DriveState,
	ChargeState,
};

extern enum AMS_State AMS_state;

extern uint16_t error_flags;

extern bool connected_to_charger;

//*****************  Voltage_Mutex Protected  ****************************
extern uint16_t cell_volt[5][28];  // Unit mV, 28 cells pr bank
extern OS_TICK cell_volt_ts[5][28]; // Timestamp for last reading inside safety intervals
extern uint32_t cell_bank_volt[5]; //voltage of cell banks consisting of 28 cells
extern uint32_t sum_of_all_cells;


//*****************  Temperature_Mutex Protected  ****************************
extern int16_t cell_temp[5][10]; // Unit 0.1C
extern OS_TICK cell_temp_ts[5][10]; // Timestamp for last reading inside safety intervals
extern OS_TICK cell_charge_temp_ts[5][10]; // Timestamp for last reading inside charging safety intervals
extern int16_t bal_temp[5][14];  // Unit 0.1C


//*****************  Power_Mutex Protected  ****************************
extern int32_t shunt_power;
extern OS_TICK shunt_power_ts;
extern int32_t shunt_power_average;
extern int32_t shunt_curr; // in mA, read from shunt
extern OS_TICK shunt_curr_ts;

//*****************  SOC_Mutex Protected  ****************************
extern uint32_t shunt_battery_volt; // in mV, read from shunt (Voltage Measurement U1)
extern OS_TICK shunt_battery_volt_ts;
extern uint8_t shunt_battery_volt_updated; // Is set to 1 upon receiving a battery volt shunt message
extern uint32_t shunt_precharge_volt; // in mV read from shunt (voltage measurement U2)
extern OS_TICK shunt_precharge_volt_ts;
extern uint8_t shunt_precharge_volt_updated; // Is set to 1 upon receiving a precharge volt shunt message
extern int32_t shunt_coulomb_counter;
extern OS_TICK shunt_coulomb_counter_ts;
extern int32_t shunt_energy_counter;
extern OS_TICK shunt_energy_counter_ts;






#endif /* COMMON_H_ */
