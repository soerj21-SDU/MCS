/*
 * ChargingTask.h
 *
 *  Created on: 1. jul. 2019
 *      Author: matt
 */

#ifndef CHARGINGTASK_H_
#define CHARGINGTASK_H_

void ChargingTask(void *arg);

#endif /* CHARGINGTASK_H_ */
