/*
 * SimulationTask.h
 *
 *  Created on: 5. jul. 2019
 *      Author: matt
 */

#ifndef SIMULATIONTASK_H_
#define SIMULATIONTASK_H_

void SimulationTask(void *arg);

#endif /* SIMULATIONTASK_H_ */
