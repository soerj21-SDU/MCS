/*
 * CanFunctions.c
 *
 *  Created on: 5. apr. 2019
 *      Author: M
 */

#include "CanFunctions.h"

#include "xil_printf.h"
#include "relay.h"
#include "shutdown.h"

 // The actual functional Shunt task. Sets up the shunt for our predesignated mode and listens to responses and saves them in data.
/*
 void CAN_Shunt_Task()
 {
	  CANFRM  can_frm;

	  CANFRM Set_mode_run_frm;
	  Set_mode_run_frm.Identifier = 0x411u;
	  Set_mode_run_frm.DLC 		  = 8u;
	  Set_mode_run_frm.Data[0]    = 0x34;   // Set_Mode
	  Set_mode_run_frm.Data[1]    = 0x01;	// Set mode stop: 0. set mode run: 1.
	  Set_mode_run_frm.Data[2]    = 0x00;   // Set mode on startup. stop: 0. run: 1.
	  Set_mode_run_frm.Data[3]    = 0x00;
	  Set_mode_run_frm.Data[4]    = 0x00;
	  Set_mode_run_frm.Data[5]    = 0x00;
	  Set_mode_run_frm.Data[6]    = 0x00;
	  Set_mode_run_frm.Data[7]    = 0x00;

	  CANFRM Set_mode_stop_frm;
	  Set_mode_stop_frm.Identifier = 0x411u;
	  Set_mode_stop_frm.DLC 		  = 8u;
	  Set_mode_stop_frm.Data[0]    = 0x34;   // Set_Mode
	  Set_mode_stop_frm.Data[1]    = 0x00;	// Set mode stop: 0. set mode run: 1.
	  Set_mode_stop_frm.Data[2]    = 0x00;   // Set mode on startup. stop: 0. run: 1.
	  Set_mode_stop_frm.Data[3]    = 0x00;
	  Set_mode_stop_frm.Data[4]    = 0x00;
	  Set_mode_stop_frm.Data[5]    = 0x00;
	  Set_mode_stop_frm.Data[6]    = 0x00;
	  Set_mode_stop_frm.Data[7]    = 0x00;

	  CANFRM config_current_frm;
	  config_current_frm.Identifier = 0x411u;
	  config_current_frm.DLC 		  = 8u;
	  config_current_frm.Data[0]    = 0x20; // low nibble: 0 = current, high nibble: 2 = result config
	  config_current_frm.Data[1]    = 0x02; //low nibble: 0 = disabled, 1 = triggered, 2 = cyclic
	  config_current_frm.Data[2]    = 0x00; //output cycletime(ms)/measurement-interval/trigger delay
	  config_current_frm.Data[3]    = 0x64; //output cycletime(ms)/measurement-interval/trigger delay
	  config_current_frm.Data[4]    = 0x00;
	  config_current_frm.Data[5]    = 0x00;
	  config_current_frm.Data[6]    = 0x00;
	  config_current_frm.Data[7]    = 0x00;

	  CANFRM config_voltage1_frm;
	  config_voltage1_frm.Identifier = 0x411u;
	  config_voltage1_frm.DLC 		  = 8u;
	  config_voltage1_frm.Data[0]    = 0x21; // low nibble: 1 = voltage1, high nibble: 2 = result config
	  config_voltage1_frm.Data[1]    = 0x02; //low nibble: 0 = disabled, 1 = triggered, 2 = cyclic
	  config_voltage1_frm.Data[2]    = 0x00; //output cycletime(ms)/measurement-interval/trigger delay
	  config_voltage1_frm.Data[3]    = 0x64;//output cycletime(ms)/measurement-interval/trigger delay
	  config_voltage1_frm.Data[4]    = 0x00;
	  config_voltage1_frm.Data[5]    = 0x00;
	  config_voltage1_frm.Data[6]    = 0x00;
	  config_voltage1_frm.Data[7]    = 0x00;

	  CANFRM config_voltage2_frm;
	  config_voltage2_frm.Identifier = 0x411u;
	  config_voltage2_frm.DLC 		  = 8u;
	  config_voltage2_frm.Data[0]    = 0x22; // low nibble: 2 = voltage2, high nibble: 2 = result config
	  config_voltage2_frm.Data[1]    = 0x00; //low nibble: 0 = disabled, 1 = triggered, 2 = cyclic
	  config_voltage2_frm.Data[2]    = 0x00; //output cycletime(ms)/measurement-interval/trigger delay
	  config_voltage2_frm.Data[3]    = 0xA0;//output cycletime(ms)/measurement-interval/trigger delay
	  config_voltage2_frm.Data[4]    = 0x00;
	  config_voltage2_frm.Data[5]    = 0x00;
	  config_voltage2_frm.Data[6]    = 0x00;
	  config_voltage2_frm.Data[7]    = 0x00;

	  CANFRM config_voltage3_frm;
	  config_voltage3_frm.Identifier = 0x411u;
	  config_voltage3_frm.DLC 		  = 8u;
	  config_voltage3_frm.Data[0]    = 0x23; // low nibble: 3 = voltage3, high nibble: 2 = result config
	  config_voltage3_frm.Data[1]    = 0x00; //low nibble: 0 = disabled, 1 = triggered, 2 = cyclic
	  config_voltage3_frm.Data[2]    = 0x00; //output cycletime(ms)/measurement-interval/trigger delay
	  config_voltage3_frm.Data[3]    = 0xA0;//output cycletime(ms)/measurement-interval/trigger delay
	  config_voltage3_frm.Data[4]    = 0x00;
	  config_voltage3_frm.Data[5]    = 0x00;
	  config_voltage3_frm.Data[6]    = 0x00;
	  config_voltage3_frm.Data[7]    = 0x00;

	  int timeout = 50;
	  CanBusIoCtl(ZC7xxx_CAN_BUS_0, CANBUS_SET_RX_TIMEOUT, &timeout);   // Set Timeout to wait a short time for new CAN Msg.


	    //Result configuration

	  while(1)
	  {
	  UCOS_Print("sent stop on CAN0\r\n");
	  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&Set_mode_stop_frm, sizeof(CANFRM));  //set mode to stop for configuration
      CanBusRead(         ZC7xxx_CAN_BUS_0,               					      // Pend till New CAN msg is found on CAN BUS
                 (void *)&can_frm,
                          sizeof(CANFRM));
      if (can_frm.Data[0] == 0xb4 && can_frm.Data[1]== 0x00 && can_frm.Data[2] == 0x00) break;				  //Identify correct response Message.
      else {printf("Received an unknown message on CAN0(1): %x %x %x %x %x %x %x %x \n", can_frm.Data[0],can_frm.Data[1],can_frm.Data[2],can_frm.Data[3],can_frm.Data[4],can_frm.Data[5],can_frm.Data[6],can_frm.Data[7]);}
      OSTimeDlyHMSM(0u, 0u, 0u, 500u, OS_OPT_TIME_DLY, &CAN_SHUNT_ERR);
	  }

	  while(1)
	  {
	  UCOS_Print("sent current config\r\n");
	  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&config_current_frm, sizeof(CANFRM)); // set up current monitoring.
      CanBusRead(         ZC7xxx_CAN_BUS_0,                  					  // Pend till New CAN msg is found on CAN BUS
                 (void *)&can_frm,
                          sizeof(CANFRM));
      if (can_frm.Data[0] == 0xA0 && can_frm.Data[1]== 0x02 && can_frm.Data[2] == 0x00 && can_frm.Data[3] == 0x64) break;				  //Identify correct response Message.
      else {printf("Received an unknown message on CAN0(2): %x %x %x %x %x %x %x %x \n", can_frm.Data[0],can_frm.Data[1],can_frm.Data[2],can_frm.Data[3],can_frm.Data[4],can_frm.Data[5],can_frm.Data[6],can_frm.Data[7]);}
      OSTimeDlyHMSM(0u, 0u, 0u, 500u, OS_OPT_TIME_DLY, &CAN_SHUNT_ERR);
	  }

	  while(1)
	  {
	  UCOS_Print("sent voltage1 config\r\n");
	  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&config_voltage1_frm, sizeof(CANFRM)); // Set up voltage measurement on channel 1
      CanBusRead(         ZC7xxx_CAN_BUS_0,                  					  // Pend till New CAN msg is found on CAN BUS
                 (void *)&can_frm,
                          sizeof(CANFRM));
      if (can_frm.Data[0] == 0xA1 && can_frm.Data[1]== 0x02 && can_frm.Data[2] == 0x00 && can_frm.Data[3] == 0x64) break;																  //Identify correct response Message.
      else {printf("Received an unknown message on CAN0(3): %x %x %x %x %x %x %x %x \n", can_frm.Data[0],can_frm.Data[1],can_frm.Data[2],can_frm.Data[3],can_frm.Data[4],can_frm.Data[5],can_frm.Data[6],can_frm.Data[7]);}
      OSTimeDlyHMSM(0u, 0u, 0u, 500u, OS_OPT_TIME_DLY, &CAN_SHUNT_ERR);
	  }

	  while(1)
	  {
	  UCOS_Print("sent voltage2 config\r\n");
	  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&config_voltage2_frm, sizeof(CANFRM)); // disabling voltage channel 2
      CanBusRead(         ZC7xxx_CAN_BUS_0,                  					  // Pend till New CAN msg is found on CAN BUS
                 (void *)&can_frm,
                          sizeof(CANFRM));
      if (can_frm.Data[0] == 0xA2 && (can_frm.Data[1]&0x01)==0x00) break;				  												  //Identify correct response Message.
      else {printf("Received an unknown message on CAN0(4): %x %x %x %x %x %x %x %x \n", can_frm.Data[0],can_frm.Data[1],can_frm.Data[2],can_frm.Data[3],can_frm.Data[4],can_frm.Data[5],can_frm.Data[6],can_frm.Data[7]);}
      OSTimeDlyHMSM(0u, 0u, 0u, 500u, OS_OPT_TIME_DLY, &CAN_SHUNT_ERR);
	  }

	  while(1)
	  {
	  UCOS_Print("sent voltage3 config\r\n");
	  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&config_voltage3_frm, sizeof(CANFRM)); // disabling voltage channel 3
      CanBusRead(         ZC7xxx_CAN_BUS_0,                  					  // Pend till New CAN msg is found on CAN BUS
                 (void *)&can_frm,
                          sizeof(CANFRM));
      if (can_frm.Data[0] == 0xA3 && (can_frm.Data[1]&0x01)==0x00) break;				  												  //Identify correct response Message.
      else {printf("Received an unknown message on CAN0(5): %x %x %x %x %x %x %x %x \n", can_frm.Data[0],can_frm.Data[1],can_frm.Data[2],can_frm.Data[3],can_frm.Data[4],can_frm.Data[5],can_frm.Data[6],can_frm.Data[7]);}
      OSTimeDlyHMSM(0u, 0u, 0u, 500u, OS_OPT_TIME_DLY, &CAN_SHUNT_ERR);
	  }

	  while(1)
	  {
	  UCOS_Print("sent run on CAN0\r\n");
	  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&Set_mode_run_frm, sizeof(CANFRM)); // send message - set mode: run
      CanBusRead(         ZC7xxx_CAN_BUS_0,                  					  // Pend till New CAN msg is found on CAN BUS
                 (void *)&can_frm,
                          sizeof(CANFRM));
      if (can_frm.Data[0] == 0xB4 && can_frm.Data[1] == 0x01 && can_frm.Data[2] == 0x00) break;				  												  //Identify correct response Message.
      else {printf("Received an unknown message on CAN0(6): %x %x %x %x %x %x %x %x \n", can_frm.Data[0],can_frm.Data[1],can_frm.Data[2],can_frm.Data[3],can_frm.Data[4],can_frm.Data[5],can_frm.Data[6],can_frm.Data[7]);}
      OSTimeDlyHMSM(0u, 0u, 0u, 500u, OS_OPT_TIME_DLY, &CAN_SHUNT_ERR);
	  }
*/
/*
	  CanBusIoCtl(ZC7xxx_CAN_BUS_0, CANBUS_SET_RX_TIMEOUT, 0u);   // Set Timeout to wait forever for new CAN Msg.
	  int temp;

	  while(DEF_ON)
	  {
	      CanBusRead(         ZC7xxx_CAN_BUS_0,                   // Pend till New CAN msg is found on CAN BUS
	                 (void *)&can_frm,
	                          sizeof(CANFRM));
		  if((can_frm.Data[1] & 0b11110000) == 0)                                //the high nipple in Data[1] indicates error.
		  {
			  switch(can_frm.Data[0])  							  //each message is uniquely defined by the first byte.
			  {
			  case 0x00:  										  //result - current. measured in mA.
				  temp = (can_frm.Data[2]<<24) + (can_frm.Data[3]<<16) + (can_frm.Data[4]<<8) + can_frm.Data[5];
				  printf("Received message on CAN0. current: %d mA. %x %x %x %x %x %x %x %x\n",temp,can_frm.Data[0],can_frm.Data[1],can_frm.Data[2],can_frm.Data[3],can_frm.Data[4],can_frm.Data[5],can_frm.Data[6],can_frm.Data[7]);
				  OSMutexPend(&Data_Mutex,
				              0,
				              OS_OPT_PEND_BLOCKING,
				              0,
				              &CAN_SHUNT_ERR);
				  	  	  	  if(CAN_SHUNT_ERR != OS_ERR_NONE)
				  	  	  		  UCOS_Print("CAN0_RX_ERR\n");
				  shunt_curr = temp ;
			      OSMutexPost(&Data_Mutex,
			                  OS_OPT_POST_NONE,
							  &CAN_SHUNT_ERR);
			      if(CAN_SHUNT_ERR != OS_ERR_NONE)
				  UCOS_Print("CAN0_RX_ERR\n");
			      break;

			  case 0x01:  										  //result - U1,voltage measured in mV.
				  temp =(can_frm.Data[2]<<24) + (can_frm.Data[3]<<16) + (can_frm.Data[4]<<8) + can_frm.Data[5];
				  printf("Received message on CAN0. voltage 1: %d mV. %x %x %x %x %x %x %x %x\n",temp,can_frm.Data[0],can_frm.Data[1],can_frm.Data[2],can_frm.Data[3],can_frm.Data[4],can_frm.Data[5],can_frm.Data[6],can_frm.Data[7]);
				  OSMutexPend(&Data_Mutex,
				              0,
				              OS_OPT_PEND_BLOCKING,
				              0,
				              &CAN_SHUNT_ERR);
				  	  	  	  if(CAN_SHUNT_ERR != OS_ERR_NONE)
				  	  	  		  UCOS_Print("CAN0_RX_ERR\n");
				  shunt_battery_volt = temp;
			      OSMutexPost(&Data_Mutex,
			                  OS_OPT_POST_NONE,
							  &CAN_SHUNT_ERR);
			      if(CAN_SHUNT_ERR != OS_ERR_NONE)
				  UCOS_Print("CAN0_RX_ERR\n");
			  break;

			  default:
				  printf("Received an unknown message on CAN0(0): %x %x %x %x %x %x %x %x \n", can_frm.Data[0],can_frm.Data[1],can_frm.Data[2],can_frm.Data[3],can_frm.Data[4],can_frm.Data[5],can_frm.Data[6],can_frm.Data[7]);
			  }
	      }
		  if(can_frm.Data[1] & 0b00010000)
		  {
			  UCOS_Print("Received message on CAN0. Open control system(shunt lost connection to TS) bit is set. CAN0\r\n");
			  			  OSMutexPend(&Data_Mutex,
			              0,
			              OS_OPT_PEND_BLOCKING,
			              0,
			              &CAN_SHUNT_ERR);
			  if(CAN_SHUNT_ERR != OS_ERR_NONE)
				  UCOS_Print("CAN0_RX_ERR\n");
			  rdy_flags |=  0b00100000; //Set error flag
		      OSMutexPost(&Data_Mutex,
		                  OS_OPT_POST_NONE,
						  &CAN_SHUNT_ERR);
		      if(CAN_SHUNT_ERR != OS_ERR_NONE)
		    	  UCOS_Print("CAN0_RX_ERR\n");
		  }
		  if(can_frm.Data[1] & 0b00100000)
		  {
			  UCOS_Print("Received message on CAN0. result is: out of range/has reduced precision/has measurement error\r\n");
		  }
		  if(can_frm.Data[1] & 0b01000000)
		  {
			  UCOS_Print("Received message on CAN0. ANY result has measurement error CAN0\r\n"); //do we need a measurement error flag or is this also just a straight error.
		  }
		  if(can_frm.Data[1] & 0b10000000)
		  {
			  UCOS_Print("Received message on CAN0. SYSTEM ERROR\r\n");
			  OSMutexPend(&Data_Mutex,
			              0,
			              OS_OPT_PEND_BLOCKING,
			              0,
			              &CAN_SHUNT_ERR);
			  if(CAN_SHUNT_ERR != OS_ERR_NONE)
				  UCOS_Print("CAN0_RX_ERR\n");
			  rdy_flags |= 0b00100000;  //set error flag
		      OSMutexPost(&Data_Mutex,
		                  OS_OPT_POST_NONE,
						  &CAN_SHUNT_ERR);
		      if(CAN_SHUNT_ERR != OS_ERR_NONE)
		    	  UCOS_Print("CAN0_RX_ERR\n");
		  }
	  }
*/
//}

void Shuntmessage_Error_Check( CANFRM can_frm)
{
	if(can_frm.Data[1] & 0b00010000)
	{
		 if (debug_bool)UCOS_Print("Received shunt result message on CAN. Open control system(shunt lost connection to TS) bit is set. CAN0\r\n");
		 OSMutexPend(&Controlvariable_Mutex, 0, OS_OPT_PEND_BLOCKING, 0, &CAN_SHUNT_ERR);
		 if(CAN_SHUNT_ERR != OS_ERR_NONE)
			UCOS_Print("CAN0_RX_ERR\n");
		 error_flags |= (1 << 5);
		 OSMutexPost(&Controlvariable_Mutex, OS_OPT_POST_NONE, &CAN_SHUNT_ERR);
		 if(CAN_SHUNT_ERR != OS_ERR_NONE)
			 UCOS_Print("CAN0_RX_ERR\n");
	}
	if(can_frm.Data[1] & 0b00100000)
	{
		 UCOS_Print("Received shunt result message on CAN. result is: out of range/has reduced precision/has measurement error\r\n");
	}
	if(can_frm.Data[1] & 0b01000000)
	{
		 UCOS_Print("Received shunt result message on CAN. ANY result has measurement error CAN0\r\n"); //do we need a measurement error flag or is this also just a straight error.
	}
	if(can_frm.Data[1] & 0b10000000)
	{
		 UCOS_Print("Received shunt result message on CAN. SYSTEM ERROR\r\n");
		 OSMutexPend(&Controlvariable_Mutex, 0, OS_OPT_PEND_BLOCKING, 0, &CAN_SHUNT_ERR);
		 if(CAN_SHUNT_ERR != OS_ERR_NONE)
			 UCOS_Print("CAN0_RX_ERR\n");
		 error_flags |= (1 << 5);
		 OSMutexPost(&Controlvariable_Mutex, OS_OPT_POST_NONE, &CAN_SHUNT_ERR);
		 if(CAN_SHUNT_ERR != OS_ERR_NONE)
			 UCOS_Print("CAN0_RX_ERR\n");
	}
	return;
}

 void  CAN1_RxTask()
 {
	 CANFRM can_frm;
	 CanBusIoCtl(ZC7xxx_CAN_BUS_0, CANBUS_SET_RX_TIMEOUT, 0u);   // Set Timeout to wait forever for new CAN Msg.
	 int temp;
reset_flag = 0;

	 while (DEF_ON)
	 {
	     CanBusRead( ZC7xxx_CAN_BUS_0,                   // Pend till New CAN msg is found on CAN BUS
	                 (void *)&can_frm,
	                 sizeof(CANFRM));
	     if (debug_bool){UCOS_Print("Received something on CAN \n");}

	     switch (can_frm.Identifier)
	     {
	     case 0x401: //Master Command Message
	    	 OSMutexPend(&Controlvariable_Mutex, 0, OS_OPT_PEND_BLOCKING, 0, &CAN1_RX_ERR);
   		  	 if(CAN1_RX_ERR!= OS_ERR_NONE)
   		  	 {
   		  		 UCOS_Print("CAN rx, controlvariable mutex error\n");
   		  	 }

   		  	 //if((can_frm.Data[0]&0b1111)==1 ||(can_frm.Data[0]&0b1111)==1<<1||(can_frm.Data[0]&0b1111)==1<<2||(can_frm.Data[0]&0b1111)==1<<3||(can_frm.Data[0]&0b1111)==1<<4)
   		  	 // {rdy_flags |= can_frm.Data[0];}

   		  	 cmd_flags = can_frm.Data[0] &0b11111;

   		  	 if(can_frm.Data[0] & (1 << 5))
   		  		 reset_flag = 1;

   		  	 connected_to_charger = can_frm.Data[0] & (1 << 6);

   		  	 charging_scaler = can_frm.Data[1];

   		  	 /*
   		     uint8_t temp_bank_count = can_frm.Data[2];
   		     if (temp_bank_count > 5)
   		    	 bank_count = 5;
   		     else
   		    	 bank_count = temp_bank_count;
   		     */

   		     OSMutexPost(&Controlvariable_Mutex, OS_OPT_POST_NONE, &CAN1_RX_ERR);
   		  	 if(CAN1_RX_ERR!= OS_ERR_NONE)
   		  	 {
   		  		 UCOS_Print("CAN rx, controlvariable mutex error\n");
   		  	 }
	     	 break;

	     case 0x521: // IVT_Msg_Result_I
	    	 if((can_frm.Data[1] & 0b11110000) == 0)                                //the high nipple in Data[1] indicates error.
			 {
	    		 temp = (can_frm.Data[2]<<24) + (can_frm.Data[3]<<16) + (can_frm.Data[4]<<8) + can_frm.Data[5];
			  	 if(debug_bool){
			  		 printf("Received message on CAN. current: %d mA. %x %x %x %x %x %x %x %x\n",temp,can_frm.Data[0],can_frm.Data[1],can_frm.Data[2],can_frm.Data[3],can_frm.Data[4],can_frm.Data[5],can_frm.Data[6],can_frm.Data[7]);}
			  	 OSMutexPend(&Power_Mutex, 0, OS_OPT_PEND_BLOCKING, 0, &CAN_SHUNT_ERR);
			  	 if(CAN_SHUNT_ERR != OS_ERR_NONE)
			  	  	 UCOS_Print("CAN0_RX_ERR\n");
			  	 shunt_curr = temp ;
			  	shunt_curr_ts = OSTimeGet(&CAN1_RX_ERR);
			  	 OSMutexPost(&Power_Mutex, OS_OPT_POST_NONE, &CAN_SHUNT_ERR);
			  	 if(CAN_SHUNT_ERR != OS_ERR_NONE)
			  	  	 UCOS_Print("CAN0_RX_ERR\n");
			 }
	    	 Shuntmessage_Error_Check(can_frm);
	    	 break;

	     case 0x522: //IVT_Msg_Result_U1
	    	 if((can_frm.Data[1] & 0b11110000) == 0)                                //the high nipple in Data[1] indicates error.
			 {
	    		 temp = (can_frm.Data[2]<<24) + (can_frm.Data[3]<<16) + (can_frm.Data[4]<<8) + can_frm.Data[5];
			  	 if(debug_bool){
			  		 printf("Received message on CAN. VOLTAGE1: %d mV. %x %x %x %x %x %x %x %x\n",temp,can_frm.Data[0],can_frm.Data[1],can_frm.Data[2],can_frm.Data[3],can_frm.Data[4],can_frm.Data[5],can_frm.Data[6],can_frm.Data[7]);}
			  	 OSMutexPend(&SOC_Mutex, 0, OS_OPT_PEND_BLOCKING, 0, &CAN_SHUNT_ERR);
			  	 if(CAN_SHUNT_ERR != OS_ERR_NONE)
			  	  	 UCOS_Print("CAN_RX_ERR\n");
			  	 shunt_battery_volt = temp ;
				 shunt_battery_volt_ts = OSTimeGet(&CAN1_RX_ERR);
				 shunt_battery_volt_updated = true;
			  	 OSMutexPost(&SOC_Mutex, OS_OPT_POST_NONE, &CAN_SHUNT_ERR);
			  	 if(CAN_SHUNT_ERR != OS_ERR_NONE)
			  	  	 UCOS_Print("CAN_RX_ERR\n");
			 }
	    	 Shuntmessage_Error_Check(can_frm);
	    	 break;
	     case 0x523: //IVT_Msg_Result_U2
	    	 if((can_frm.Data[1] & 0b11110000) == 0)                                //the high nipple in Data[1] indicates error.
			 {
	    		 temp = (can_frm.Data[2]<<24) + (can_frm.Data[3]<<16) + (can_frm.Data[4]<<8) + can_frm.Data[5];
			  	 if(debug_bool){
			  		 printf("Received message on CAN. voltage2: %d mV. %x %x %x %x %x %x %x %x\n",temp,can_frm.Data[0],can_frm.Data[1],can_frm.Data[2],can_frm.Data[3],can_frm.Data[4],can_frm.Data[5],can_frm.Data[6],can_frm.Data[7]);}
			  	 OSMutexPend(&SOC_Mutex, 0, OS_OPT_PEND_BLOCKING, 0, &CAN_SHUNT_ERR);
			  	 if(CAN_SHUNT_ERR != OS_ERR_NONE)
			  	  	 UCOS_Print("CAN_RX_ERR\n");
			  	 shunt_precharge_volt = temp ;
			  	 shunt_precharge_volt_ts = OSTimeGet(&CAN1_RX_ERR);
			  	 shunt_precharge_volt_updated = true;
			  	 OSMutexPost(&SOC_Mutex, OS_OPT_POST_NONE, &CAN_SHUNT_ERR);
			  	 if(CAN_SHUNT_ERR != OS_ERR_NONE)
			  	  	 UCOS_Print("CAN_RX_ERR\n");
			 }
	    	 Shuntmessage_Error_Check(can_frm);
	    	 break;

	     case 0x526://IVT_Msg_Result_W
	    	 if((can_frm.Data[1] & 0b11110000) == 0)                                //the high nipple in Data[1] indicates error.
			 {
	    		 temp = (can_frm.Data[2]<<24) + (can_frm.Data[3]<<16) + (can_frm.Data[4]<<8) + can_frm.Data[5];
			  	 if(debug_bool){
			  		 printf("Received message on CAN. Power: %d W. %x %x %x %x %x %x %x %x\n",temp,can_frm.Data[0],can_frm.Data[1],can_frm.Data[2],can_frm.Data[3],can_frm.Data[4],can_frm.Data[5],can_frm.Data[6],can_frm.Data[7]);}
			  	 OSMutexPend(&Power_Mutex, 0, OS_OPT_PEND_BLOCKING, 0, &CAN_SHUNT_ERR);
			  	 if(CAN_SHUNT_ERR != OS_ERR_NONE)
			  	  	 UCOS_Print("CAN_RX_ERR\n");
			  	 shunt_power = temp ;
			   	 shunt_power_ts = OSTimeGet(&CAN1_RX_ERR);
			  	 OSMutexPost(&Power_Mutex, OS_OPT_POST_NONE, &CAN_SHUNT_ERR);
			  	 if(CAN_SHUNT_ERR != OS_ERR_NONE)
			  	  	 UCOS_Print("CAN_RX_ERR\n");
			 }
	    	 Shuntmessage_Error_Check(can_frm);
	    	 break;

	     case 0x527: //A*s
    	 if((can_frm.Data[1] & 0b11110000) == 0)                                //the high nipple in Data[1] indicates error.
		 {
    		 temp = (can_frm.Data[2]<<24) + (can_frm.Data[3]<<16) + (can_frm.Data[4]<<8) + can_frm.Data[5];
		  	 if(debug_bool){
		  		 printf("Received message on CAN. coulomb count: %d C. %x %x %x %x %x %x %x %x\n",temp,can_frm.Data[0],can_frm.Data[1],can_frm.Data[2],can_frm.Data[3],can_frm.Data[4],can_frm.Data[5],can_frm.Data[6],can_frm.Data[7]);}
		  	 OSMutexPend(&SOC_Mutex, 0, OS_OPT_PEND_BLOCKING, 0, &CAN_SHUNT_ERR);
		  	 if(CAN_SHUNT_ERR != OS_ERR_NONE)
		  	  	 UCOS_Print("CAN_RX_ERR\n");
		  	 shunt_coulomb_counter = temp ;
		  	 shunt_coulomb_counter_ts = OSTimeGet(&CAN1_RX_ERR);
		  	 OSMutexPost(&SOC_Mutex, OS_OPT_POST_NONE, &CAN_SHUNT_ERR);
		  	 if(CAN_SHUNT_ERR != OS_ERR_NONE)
		  	  	 UCOS_Print("CAN_RX_ERR\n");
		 }
    	 Shuntmessage_Error_Check(can_frm);
		 break;

	     case 0x528:
	    	 if((can_frm.Data[1] & 0b11110000) == 0)                                //the high nipple in Data[1] indicates error.
			 {
	    		 temp = (can_frm.Data[2]<<24) + (can_frm.Data[3]<<16) + (can_frm.Data[4]<<8) + can_frm.Data[5];
			  	 if(debug_bool){
			  		 printf("Received message on CAN. energy counter: %d Wh. %x %x %x %x %x %x %x %x\n",temp,can_frm.Data[0],can_frm.Data[1],can_frm.Data[2],can_frm.Data[3],can_frm.Data[4],can_frm.Data[5],can_frm.Data[6],can_frm.Data[7]);}
			  	 OSMutexPend(&SOC_Mutex, 0, OS_OPT_PEND_BLOCKING, 0, &CAN_SHUNT_ERR);
			  	 if(CAN_SHUNT_ERR != OS_ERR_NONE)
			  	  	 UCOS_Print("CAN_RX_ERR\n");
			  	 shunt_energy_counter = temp ;
			  	shunt_energy_counter_ts = OSTimeGet(&CAN1_RX_ERR);
			  	 OSMutexPost(&SOC_Mutex, OS_OPT_POST_NONE, &CAN_SHUNT_ERR);
			  	 if(CAN_SHUNT_ERR != OS_ERR_NONE)
			  	  	 UCOS_Print("CAN_RX_ERR\n");
			 }
	    	 Shuntmessage_Error_Check(can_frm);
	    	 break;
	     case 0x511:  //shunt command response message.
	    	 break;

	     default:
	    	 if (debug_bool)
	    		 UCOS_Print("Received CAN Message with unknown identifier");

	     }
	 }
 }

//void* temp;
// OSTaskQPost(&CAN1_TX_TCB,      //Signal CAN0_TxTask to start data collection.
//		  (void*)temp,
	//	  sizeof((void*)temp),
//		  OS_OPT_POST_FIFO,
//&CAN1_RX_ERR);

// OS_MSG_SIZE msg_size;
//	  void * msg_p;
//msg_p = OSTaskQPend(0,
//		OS_OPT_PEND_BLOCKING,
//		&msg_size,
//		0,
//		&CAN1_TX_ERR);
//  if(CAN1_TX_ERR != OS_ERR_NONE)
//	  UCOS_Print("CAN0_RX_ERR\n");

//  printf("Received message on CAN0. message id: %d.\n",(int)msg_p);



 void  CAN1_TxTask()
 {

	  //CAN1 is The contact with the BD90 MASTER-MASTER-controller.
	  //The task must send certain messages periodically. Messages contain information collected
	  //by or about the BMS.
	  //Messages with cycletime 100:
	  // - SC
	  // - status
	  // - Bank voltages 1
	  // - Bank voltages 2
	  // - AMSData
	  // - CellVoltages1Bank1
	  // - CellVoltages2Bank1
	  // - CellVoltages3Bank1
	  // - CellVoltages4Bank1
	  //Messages with cycletime 900
	  // - CellTemperatures1Bank1
	  // - CellTemperatures2Bank1
	  // - BalancingResistorTemperatures1Bank1
	  // - BalancingResistorTemperatures2Bank1
	  // - BalancingResistorTemperatures3Bank1

	  //Artificial data readings for Testing CAN1 TX.
	 /*
	  OSMutexPend(&Voltage_Mutex, 0, OS_OPT_PEND_BLOCKING, 0, &CAN1_TX_ERR);
	  if(CAN1_TX_ERR != OS_ERR_NONE)
	  { UCOS_Print("AMS Control Error\n");}

	  for (int j = 0; j < 5; j++)
	  {
		  for(int i= 0; i<28 ; i++)
		  {
			  cell_volt[j][i] = 2000+(j*28+i)*10;
		  }
	  }

	  for(int i = 0; i < 5 ; i++) cell_bank_volt[i] = (i+1)*10000;

	  OSMutexPost(&Voltage_Mutex, OS_OPT_POST_NONE, &CAN1_TX_ERR);
	  if(CAN1_TX_ERR != OS_ERR_NONE)
	     UCOS_Print("AMS Control Error \n");

	  OSMutexPend(&Temperature_Mutex, 0, OS_OPT_PEND_BLOCKING, 0, &CAN1_TX_ERR);
	  if(CAN1_TX_ERR != OS_ERR_NONE)
	  { UCOS_Print("AMS Control Error\n");}

	  for(int j = 0; j < 5 ; j++)
	  {
		  for(int i=0; i< 10 ;i++)
		  {cell_temp[j][i] = (j*10+i)*10;}
	  }

	  for(int j = 0; j < 5 ; j++)
	  {
		  for(int i=0; i< 14 ;i++)
		  {bal_temp[j][i] = (j*14+i)*10;}
	  }

	  master_temp = 1200;

	  OSMutexPost(&Temperature_Mutex, OS_OPT_POST_NONE, &CAN1_TX_ERR);
	  if(CAN1_TX_ERR != OS_ERR_NONE)
	     UCOS_Print("AMS Control Error \n");

	  OSMutexPend(&Power_Mutex, 0, OS_OPT_PEND_BLOCKING, 0, &CAN1_TX_ERR);
	  if(CAN1_TX_ERR != OS_ERR_NONE)
	  { UCOS_Print("AMS Control Error\n");}
	  shunt_power = 2500000;
	  shunt_curr = 15000;

	  OSMutexPost(&Power_Mutex, OS_OPT_POST_NONE, &CAN1_TX_ERR);
	  if(CAN1_TX_ERR != OS_ERR_NONE)
	     UCOS_Print("AMS Control Error \n");


	  OSMutexPend(&Controlvariable_Mutex, 0, OS_OPT_PEND_BLOCKING, 0, &CAN1_TX_ERR);
	  if(CAN1_TX_ERR != OS_ERR_NONE)
	  { UCOS_Print("AMS Control Error\n");}

	  status = 0b01010100;        // bit7: SC-Enable State, bit6 pre-charge relay, bit5 AIR+, bit4 = AIR-, bit3: drive State, bit2: precharge State , bit1: charging State, bit0: Idle State
	  AMS_flags = 0b00000001;
	  sc = 19;            // safety chain flags.   bit3: SC_ENABLE.  bit2: SC_HVD_INTERLOCK. bit1: SC_AMS_ERROR. bit0: SC_IMD_ERROR

	  OSMutexPost(&Controlvariable_Mutex, OS_OPT_POST_NONE, &CAN1_TX_ERR);
	  if(CAN1_TX_ERR != OS_ERR_NONE)
	     UCOS_Print("AMS Control Error \n");


	  OSMutexPend(&SOC_Mutex, 0, OS_OPT_PEND_BLOCKING, 0, &CAN1_TX_ERR);
	  if(CAN1_TX_ERR != OS_ERR_NONE)
	  { UCOS_Print("AMS Control Error\n");}
	  shunt_coulomb_counter = 1000000;
	  shunt_energy_counter = 500000;
	  OSMutexPost(&SOC_Mutex, OS_OPT_POST_NONE, &CAN1_TX_ERR);
	  if(CAN1_TX_ERR != OS_ERR_NONE)
	     UCOS_Print("AMS Control Error \n");
//*/

// Frame definitions for CAN1 TX

	  CANFRM Set_mode_stop_frm;
	  Set_mode_stop_frm.Identifier = 0x411u;
	  Set_mode_stop_frm.DLC 		  = 8u;
	  Set_mode_stop_frm.Data[0]    = 0x34;   // Set_Mode
	  Set_mode_stop_frm.Data[1]    = 0x00;	// Set mode stop: 0. set mode run: 1.
	  Set_mode_stop_frm.Data[2]    = 0x01;   // Set mode on startup. stop: 0. run: 1.
	  Set_mode_stop_frm.Data[3]    = 0x00;
	  Set_mode_stop_frm.Data[4]    = 0x00;
	  Set_mode_stop_frm.Data[5]    = 0x00;
	  Set_mode_stop_frm.Data[6]    = 0x00;
	  Set_mode_stop_frm.Data[7]    = 0x00;


	  CANFRM Restart_frm;
	  Set_mode_stop_frm.Identifier = 0x411u;
	  Set_mode_stop_frm.DLC 	   = 8u;
	  Set_mode_stop_frm.Data[0]    = 0x3F;
	  Set_mode_stop_frm.Data[1]    = 0x00;
	  Set_mode_stop_frm.Data[2]    = 0x00;
	  Set_mode_stop_frm.Data[3]    = 0x00;
	  Set_mode_stop_frm.Data[4]    = 0x00;
	  Set_mode_stop_frm.Data[5]    = 0x00;
	  Set_mode_stop_frm.Data[6]    = 0x00;
	  Set_mode_stop_frm.Data[7]    = 0x00;


      CANFRM sc_frm;
	  sc_frm.Identifier = 0x400u;
	  sc_frm.DLC        = 1u;

	  CANFRM status_frm;
	  status_frm.Identifier = 0x402u;   //402 status message identifier.
	  status_frm.DLC 		  = 6u;

	  CANFRM bank_voltages1_frm;
	  bank_voltages1_frm.Identifier = 0x405u;
	  bank_voltages1_frm.DLC 		  = 6u;

	  CANFRM bank_voltages2_frm;
	  bank_voltages2_frm.Identifier = 0x406u;
	  bank_voltages2_frm.DLC 		  = 4u;

	  CANFRM data_frm;
	  data_frm.Identifier = 0x407u;
	  data_frm.DLC = 8u;

	  CANFRM soc_frm;
	  soc_frm.Identifier = 0x408u;
	  soc_frm.DLC = 6u;

	  //***********************         1     *************************
	  CANFRM cellbank1_voltages1_frm;
	  cellbank1_voltages1_frm.Identifier = 0x410u;
	  cellbank1_voltages1_frm.DLC = 8u;

	  CANFRM cellbank1_voltages2_frm;
	  cellbank1_voltages2_frm.Identifier = 0x412u;
	  cellbank1_voltages2_frm.DLC = 8u;

	  CANFRM cellbank1_voltages3_frm;
	  cellbank1_voltages3_frm.Identifier = 0x413u;
	  cellbank1_voltages3_frm.DLC = 8u;

	  CANFRM cellbank1_voltages4_frm;
	  cellbank1_voltages4_frm.Identifier = 0x414u;
	  cellbank1_voltages4_frm.DLC = 4u;

	  CANFRM temp_bank1_cell1_frm;
	  temp_bank1_cell1_frm.Identifier = 0x415u;
	  temp_bank1_cell1_frm.DLC        = 8u;

	  CANFRM temp_bank1_cell2_frm;
	  temp_bank1_cell2_frm.Identifier = 0x416u;
	  temp_bank1_cell2_frm.DLC        = 8u;

	  CANFRM temp_bank1_cell3_frm;
	  temp_bank1_cell3_frm.Identifier = 0x417u;
	  temp_bank1_cell3_frm.DLC = 4u;

	  CANFRM bal_bank1_temp1_frm;
	  bal_bank1_temp1_frm.Identifier = 0x41Au;
	  bal_bank1_temp1_frm.DLC = 8u;

	  CANFRM bal_bank1_temp2_frm;
	  bal_bank1_temp2_frm.Identifier = 0x41Bu;
	  bal_bank1_temp2_frm.DLC = 8u;

	  CANFRM bal_bank1_temp3_frm;
	  bal_bank1_temp3_frm.Identifier = 0x41Cu;
	  bal_bank1_temp3_frm.DLC = 8u;

	  CANFRM bal_bank1_temp4_frm;
	  bal_bank1_temp4_frm.Identifier = 0x41Du;
	  bal_bank1_temp4_frm.DLC = 4u;

	  //************************'      2      **********************
	  CANFRM cellbank2_voltages1_frm;
	  cellbank2_voltages1_frm.Identifier = 0x420u;
	  cellbank2_voltages1_frm.DLC = 8u;

	  CANFRM cellbank2_voltages2_frm;
	  cellbank2_voltages2_frm.Identifier = 0x422u;
	  cellbank2_voltages2_frm.DLC = 8u;

	  CANFRM cellbank2_voltages3_frm;
	  cellbank2_voltages3_frm.Identifier = 0x423u;
	  cellbank2_voltages3_frm.DLC = 8u;

	  CANFRM cellbank2_voltages4_frm;
	  cellbank2_voltages4_frm.Identifier = 0x424u;
	  cellbank2_voltages4_frm.DLC = 4u;

	  CANFRM temp_bank2_cell1_frm;
	  temp_bank2_cell1_frm.Identifier = 0x425u;
	  temp_bank2_cell1_frm.DLC        = 8u;

	  CANFRM temp_bank2_cell2_frm;
	  temp_bank2_cell2_frm.Identifier = 0x426u;
	  temp_bank2_cell2_frm.DLC        = 8u;

	  CANFRM temp_bank2_cell3_frm;
	  temp_bank2_cell3_frm.Identifier = 0x427u;
	  temp_bank2_cell3_frm.DLC = 4u;

	  CANFRM bal_bank2_temp1_frm;
	  bal_bank2_temp1_frm.Identifier = 0x42Au;
	  bal_bank2_temp1_frm.DLC = 8u;

	  CANFRM bal_bank2_temp2_frm;
	  bal_bank2_temp2_frm.Identifier = 0x42Bu;
	  bal_bank2_temp2_frm.DLC = 8u;

	  CANFRM bal_bank2_temp3_frm;
	  bal_bank2_temp3_frm.Identifier = 0x42Cu;
	  bal_bank2_temp3_frm.DLC = 8u;

	  CANFRM bal_bank2_temp4_frm;
	  bal_bank2_temp4_frm.Identifier = 0x42Du;
	  bal_bank2_temp4_frm.DLC = 4u;
	  //************************  3 ************************************
	  CANFRM cellbank3_voltages1_frm;
	  cellbank3_voltages1_frm.Identifier = 0x430u;
	  cellbank3_voltages1_frm.DLC = 8u;

	  CANFRM cellbank3_voltages2_frm;
	  cellbank3_voltages2_frm.Identifier = 0x432u;
	  cellbank3_voltages2_frm.DLC = 8u;

	  CANFRM cellbank3_voltages3_frm;
	  cellbank3_voltages3_frm.Identifier = 0x433u;
	  cellbank3_voltages3_frm.DLC = 8u;

	  CANFRM cellbank3_voltages4_frm;
	  cellbank3_voltages4_frm.Identifier = 0x434u;
	  cellbank3_voltages4_frm.DLC = 4u;

	  CANFRM temp_bank3_cell1_frm;
	  temp_bank3_cell1_frm.Identifier = 0x435u;
	  temp_bank3_cell1_frm.DLC        = 8u;

	  CANFRM temp_bank3_cell2_frm;
	  temp_bank3_cell2_frm.Identifier = 0x436u;
	  temp_bank3_cell2_frm.DLC        = 8u;

	  CANFRM temp_bank3_cell3_frm;
	  temp_bank3_cell3_frm.Identifier = 0x437u;
	  temp_bank3_cell3_frm.DLC = 4u;

	  CANFRM bal_bank3_temp1_frm;
	  bal_bank3_temp1_frm.Identifier = 0x43Au;
	  bal_bank3_temp1_frm.DLC = 8u;

	  CANFRM bal_bank3_temp2_frm;
	  bal_bank3_temp2_frm.Identifier = 0x43Bu;
	  bal_bank3_temp2_frm.DLC = 8u;

	  CANFRM bal_bank3_temp3_frm;
	  bal_bank3_temp3_frm.Identifier = 0x43Cu;
	  bal_bank3_temp3_frm.DLC = 8u;

	  CANFRM bal_bank3_temp4_frm;
	  bal_bank3_temp4_frm.Identifier = 0x43Du;
	  bal_bank3_temp4_frm.DLC = 4u;
	  //************************  4   ************************************

	  CANFRM cellbank4_voltages1_frm;
	  cellbank4_voltages1_frm.Identifier = 0x440u;
	  cellbank4_voltages1_frm.DLC = 8u;

	  CANFRM cellbank4_voltages2_frm;
	  cellbank4_voltages2_frm.Identifier = 0x442u;
	  cellbank4_voltages2_frm.DLC = 8u;

	  CANFRM cellbank4_voltages3_frm;
	  cellbank4_voltages3_frm.Identifier = 0x443u;
	  cellbank4_voltages3_frm.DLC = 8u;

	  CANFRM cellbank4_voltages4_frm;
	  cellbank4_voltages4_frm.Identifier = 0x444u;
	  cellbank4_voltages4_frm.DLC = 4u;

	  CANFRM temp_bank4_cell1_frm;
	  temp_bank4_cell1_frm.Identifier = 0x445u;
	  temp_bank4_cell1_frm.DLC        = 8u;

	  CANFRM temp_bank4_cell2_frm;
	  temp_bank4_cell2_frm.Identifier = 0x446u;
	  temp_bank4_cell2_frm.DLC        = 8u;

	  CANFRM temp_bank4_cell3_frm;
	  temp_bank4_cell3_frm.Identifier = 0x447u;
	  temp_bank4_cell3_frm.DLC = 4u;

	  CANFRM bal_bank4_temp1_frm;
	  bal_bank4_temp1_frm.Identifier = 0x44Au;
	  bal_bank4_temp1_frm.DLC = 8u;

	  CANFRM bal_bank4_temp2_frm;
	  bal_bank4_temp2_frm.Identifier = 0x44Bu;
	  bal_bank4_temp2_frm.DLC = 8u;

	  CANFRM bal_bank4_temp3_frm;
	  bal_bank4_temp3_frm.Identifier = 0x44Cu;
	  bal_bank4_temp3_frm.DLC = 8u;

	  CANFRM bal_bank4_temp4_frm;
	  bal_bank4_temp4_frm.Identifier = 0x44Du;
	  bal_bank4_temp4_frm.DLC = 4u;

	  //************************  5   ************************************
	  CANFRM cellbank5_voltages1_frm;
	  cellbank5_voltages1_frm.Identifier = 0x450u;
	  cellbank5_voltages1_frm.DLC = 8u;

	  CANFRM cellbank5_voltages2_frm;
	  cellbank5_voltages2_frm.Identifier = 0x452u;
	  cellbank5_voltages2_frm.DLC = 8u;

	  CANFRM cellbank5_voltages3_frm;
	  cellbank5_voltages3_frm.Identifier = 0x453u;
	  cellbank5_voltages3_frm.DLC = 8u;

	  CANFRM cellbank5_voltages4_frm;
	  cellbank5_voltages4_frm.Identifier = 0x454u;
	  cellbank5_voltages4_frm.DLC = 4u;

	  CANFRM temp_bank5_cell1_frm;
	  temp_bank5_cell1_frm.Identifier = 0x455u;
	  temp_bank5_cell1_frm.DLC        = 8u;

	  CANFRM temp_bank5_cell2_frm;
	  temp_bank5_cell2_frm.Identifier = 0x456u;
	  temp_bank5_cell2_frm.DLC        = 8u;

	  CANFRM temp_bank5_cell3_frm;
	  temp_bank5_cell3_frm.Identifier = 0x457u;
	  temp_bank5_cell3_frm.DLC = 4u;

	  CANFRM bal_bank5_temp1_frm;
	  bal_bank5_temp1_frm.Identifier = 0x45Au;
	  bal_bank5_temp1_frm.DLC = 8u;

	  CANFRM bal_bank5_temp2_frm;
	  bal_bank5_temp2_frm.Identifier = 0x45Bu;
	  bal_bank5_temp2_frm.DLC = 8u;

	  CANFRM bal_bank5_temp3_frm;
	  bal_bank5_temp3_frm.Identifier = 0x45Cu;
	  bal_bank5_temp3_frm.DLC = 8u;

	  CANFRM bal_bank5_temp4_frm;
	  bal_bank5_temp4_frm.Identifier = 0x45Du;
	  bal_bank5_temp4_frm.DLC = 4u;

OS_TICK now = 0;
OS_TICK TIMING_TICK1 = 0;
OS_TICK TIMING_TICK2 = 500;
OS_TICK TIMING_TICK3 = 0;

	 while (DEF_ON)
	 {
		  now = OSTimeGet(&CAN1_TX_ERR);

		  OSMutexPend(&Power_Mutex, 0, OS_OPT_PEND_BLOCKING, 0, &CAN1_TX_ERR);
		  if(CAN1_TX_ERR != OS_ERR_NONE)
		  { UCOS_Print("TxTask take power mutex error\n");}

			 // Formatting data frame
			 data_frm.Data[0] = shunt_power & 0xff;
			 data_frm.Data[1] = (shunt_power >> 8) & 0xff;  // In Watts
			 data_frm.Data[2] = (shunt_power >> 16) & 0xff;
			 data_frm.Data[3] = (shunt_power_average) & 0xff;    //Moving average of power.
			 data_frm.Data[4] = (shunt_power_average >> 8) & 0xff;
			 data_frm.Data[5] = (shunt_power_average >> 16) & 0xff;
			 data_frm.Data[6] = (shunt_curr/10) & 0xff;   // in 1/100 A
			 data_frm.Data[7] = (shunt_curr/10 >> 8) & 0xff;

			 OSMutexPost(&Power_Mutex,OS_OPT_POST_NONE,&CAN1_TX_ERR);
			 if(CAN1_TX_ERR != OS_ERR_NONE)
			 	  { UCOS_Print("TxTask give power mutex error\n");}



			 if(now - TIMING_TICK1 >= 1000*OS_CFG_TICK_RATE_HZ/1000)
			 {

				  OSMutexPend(&Temperature_Mutex, 0, OS_OPT_PEND_BLOCKING, 0, &CAN1_TX_ERR);
				  if(CAN1_TX_ERR != OS_ERR_NONE)
				  	  { UCOS_Print("TxTask take temperature mutex error\n");}

				  status_frm.Data[2] = master_temp >> 4;
				  status_frm.Data[3] = master_temp >> 12;

				  OSMutexPost(&Temperature_Mutex,OS_OPT_POST_NONE,&CAN1_TX_ERR);
				  if(CAN1_TX_ERR != OS_ERR_NONE)
				  	  { UCOS_Print("TxTask give temperature mutex error\n");}

				  OSMutexPend(&Voltage_Mutex, 0, OS_OPT_PEND_BLOCKING, 0, &CAN1_TX_ERR);
				  if(CAN1_TX_ERR != OS_ERR_NONE)
				  	  { UCOS_Print("TxTask take voltage mutex error\n");}
				  //Formatting Bank frames
				  bank_voltages1_frm.Data[0] = cell_bank_volt[0]/10;
				  bank_voltages1_frm.Data[1] = cell_bank_volt[0]/10 >> 8;
				  bank_voltages1_frm.Data[2] = cell_bank_volt[1]/10;
				  bank_voltages1_frm.Data[3] = cell_bank_volt[1]/10 >> 8;
				  bank_voltages1_frm.Data[4] = cell_bank_volt[2]/10;
				  bank_voltages1_frm.Data[5] = cell_bank_volt[2]/10 >> 8;
				  bank_voltages2_frm.Data[0] = cell_bank_volt[3]/10;
				  bank_voltages2_frm.Data[1] = cell_bank_volt[3]/10 >> 8;
				  bank_voltages2_frm.Data[2] = cell_bank_volt[4]/10;
				  bank_voltages2_frm.Data[3] = cell_bank_volt[4]/10 >> 8;


				  //formatting of the cell voltages. 8bits for each voltage offset with 2.
				  //This output only works in the range 2.00 V to 5.55 volt. (we can measure up to 6.55 volt.)
				  for(int i = 0; i < 8 ; i++){ cellbank1_voltages1_frm.Data[i] = cell_volt[0][i]/10 - 200;}
				  for(int i = 8; i < 16 ; i++){ cellbank1_voltages2_frm.Data[i-8] = cell_volt[0][i]/10 - 200;}
				  for(int i = 16; i < 24 ; i++){ cellbank1_voltages3_frm.Data[i-16] = cell_volt[0][i]/10 - 200;}
				  for(int i = 24; i < 28 ; i++){ cellbank1_voltages4_frm.Data[i-24] = cell_volt[0][i]/10 - 200;}

				  for(int i = 0; i < 8 ; i++){ cellbank2_voltages1_frm.Data[i] = cell_volt[1][i]/10 - 200;}
				  for(int i = 8; i < 16 ; i++){ cellbank2_voltages2_frm.Data[i-8] = cell_volt[1][i]/10 - 200;}
				  for(int i = 16; i < 24 ; i++){ cellbank2_voltages3_frm.Data[i-16] = cell_volt[1][i]/10 - 200;}
				  for(int i = 24; i < 28 ; i++){ cellbank2_voltages4_frm.Data[i-24] = cell_volt[1][i]/10 - 200;}

				  for(int i = 0; i < 8 ; i++){ cellbank3_voltages1_frm.Data[i] = cell_volt[2][i]/10 - 200;}
				  for(int i = 8; i < 16 ; i++){ cellbank3_voltages2_frm.Data[i-8] = cell_volt[2][i]/10 - 200;}
				  for(int i = 16; i < 24 ; i++){ cellbank3_voltages3_frm.Data[i-16] = cell_volt[2][i]/10 - 200;}
				  for(int i = 24; i < 28 ; i++){ cellbank3_voltages4_frm.Data[i-24] = cell_volt[2][i]/10 - 200;}

				  for(int i = 0; i < 8 ; i++){ cellbank4_voltages1_frm.Data[i] = cell_volt[3][i]/10 - 200;}
				  for(int i = 8; i < 16 ; i++){ cellbank4_voltages2_frm.Data[i-8] = cell_volt[3][i]/10 - 200;}
				  for(int i = 16; i < 24 ; i++){ cellbank4_voltages3_frm.Data[i-16] = cell_volt[3][i]/10 - 200;}
				  for(int i = 24; i < 28 ; i++){ cellbank4_voltages4_frm.Data[i-24] = cell_volt[3][i]/10 - 200;}

				  for(int i = 0; i < 8 ; i++){ cellbank5_voltages1_frm.Data[i] = cell_volt[4][i]/10 - 200;}
				  for(int i = 8; i < 16 ; i++){ cellbank5_voltages2_frm.Data[i-8] = cell_volt[4][i]/10 - 200;}
				  for(int i = 16; i < 24 ; i++){ cellbank5_voltages3_frm.Data[i-16] = cell_volt[4][i]/10 - 200;}
				  for(int i = 24; i < 28 ; i++){ cellbank5_voltages4_frm.Data[i-24] = cell_volt[4][i]/10 - 200;}

				  OSMutexPost(&Voltage_Mutex,OS_OPT_POST_NONE,&CAN1_TX_ERR);
				  if(CAN1_TX_ERR != OS_ERR_NONE)
				  	  { UCOS_Print("TxTask give voltage mutex error\n");}

				  OSMutexPend(&SOC_Mutex, 0, OS_OPT_PEND_BLOCKING, 0, &CAN1_TX_ERR);
				  if(CAN1_TX_ERR != OS_ERR_NONE)
				  	  { UCOS_Print("TxTask take soc mutex error\n");}
					 soc_frm.Data[0] = shunt_coulomb_counter & 0xff;
					 soc_frm.Data[1] = (shunt_coulomb_counter >> 8) & 0xff;  // In Watts
					 soc_frm.Data[2] = (shunt_coulomb_counter >> 16) & 0xff;
					 soc_frm.Data[3] = (shunt_energy_counter) & 0xff;    //Moving average of power.
					 soc_frm.Data[4] = (shunt_energy_counter >> 8) & 0xff;
					 soc_frm.Data[5] = (shunt_energy_counter >> 16) & 0xff;

				  OSMutexPost(&SOC_Mutex,OS_OPT_POST_NONE,&CAN1_TX_ERR);
				  if(CAN1_TX_ERR != OS_ERR_NONE)
					  { UCOS_Print("TxTask give soc mutex error\n");}
			 }

		if(now - TIMING_TICK2 >= 1000*OS_CFG_TICK_RATE_HZ/1000)
		 {
		 //Formatting Balancing resistor temperatures


			 OSMutexPend(&Temperature_Mutex, 0, OS_OPT_PEND_BLOCKING, 0, &CAN1_TX_ERR);
			 if(CAN1_TX_ERR != OS_ERR_NONE)
			 	 { UCOS_Print("TxTask take temperature mutex error\n");}
			 for(int i = 0; i < 8; i+=2){ bal_bank1_temp1_frm.Data[i] = bal_temp[0][i>>1];}
			 for(int i = 1; i < 8; i+=2){ bal_bank1_temp1_frm.Data[i] = bal_temp[0][i>>1]>>8;}
			 for(int i = 8; i < 16; i+=2){ bal_bank1_temp2_frm.Data[i-8] = bal_temp[0][i>>1];}
			 for(int i = 9; i < 16; i+=2){ bal_bank1_temp2_frm.Data[i-8] = bal_temp[0][i>>1]>>8;}
			 for(int i = 16; i < 24; i+=2){ bal_bank1_temp3_frm.Data[i-16] = bal_temp[0][i>>1];}
			 for(int i = 17; i < 24; i+=2){ bal_bank1_temp3_frm.Data[i-16] = bal_temp[0][i>>1]>>8;}
			 for(int i = 24; i < 28; i+=2){ bal_bank1_temp4_frm.Data[i-24] = bal_temp[0][i>>1];}
			 for(int i = 25; i < 28; i+=2){ bal_bank1_temp4_frm.Data[i-24] = bal_temp[0][i>>1]>>8;}

			 for(int i = 0; i < 8; i+=2){ bal_bank2_temp1_frm.Data[i] = bal_temp[1][i>>1];}
			 for(int i = 1; i < 8; i+=2){ bal_bank2_temp1_frm.Data[i] = bal_temp[1][i>>1]>>8;}
			 for(int i = 8; i < 16; i+=2){ bal_bank2_temp2_frm.Data[i-8] = bal_temp[1][i>>1];}
			 for(int i = 9; i < 16; i+=2){ bal_bank2_temp2_frm.Data[i-8] = bal_temp[1][i>>1]>>8;}
			 for(int i = 16; i < 24; i+=2){ bal_bank2_temp3_frm.Data[i-16] = bal_temp[1][i>>1];}
			 for(int i = 17; i < 24; i+=2){ bal_bank2_temp3_frm.Data[i-16] = bal_temp[1][i>>1]>>8;}
			 for(int i = 24; i < 28; i+=2){ bal_bank2_temp4_frm.Data[i-24] = bal_temp[1][i>>1];}
			 for(int i = 25; i < 28; i+=2){ bal_bank2_temp4_frm.Data[i-24] = bal_temp[1][i>>1]>>8;}

			 for(int i = 0; i < 8; i+=2){ bal_bank3_temp1_frm.Data[i] = bal_temp[2][i>>1];}
			 for(int i = 1; i < 8; i+=2){ bal_bank3_temp1_frm.Data[i] = bal_temp[2][i>>1]>>8;}
			 for(int i = 8; i < 16; i+=2){ bal_bank3_temp2_frm.Data[i-8] = bal_temp[2][i>>1];}
			 for(int i = 9; i < 16; i+=2){ bal_bank3_temp2_frm.Data[i-8] = bal_temp[2][i>>1]>>8;}
			 for(int i = 16; i < 24; i+=2){ bal_bank3_temp3_frm.Data[i-16] = bal_temp[2][i>>1];}
			 for(int i = 17; i < 24; i+=2){ bal_bank3_temp3_frm.Data[i-16] = bal_temp[2][i>>1]>>8;}
			 for(int i = 24; i < 28; i+=2){ bal_bank3_temp4_frm.Data[i-24] = bal_temp[2][i>>1];}
			 for(int i = 25; i < 28; i+=2){ bal_bank3_temp4_frm.Data[i-24] = bal_temp[2][i>>1]>>8;}

			 for(int i = 0; i < 8; i+=2){ bal_bank4_temp1_frm.Data[i] = bal_temp[3][i>>1];}
			 for(int i = 1; i < 8; i+=2){ bal_bank4_temp1_frm.Data[i] = bal_temp[3][i>>1]>>8;}
			 for(int i = 8; i < 16; i+=2){ bal_bank4_temp2_frm.Data[i-8] = bal_temp[3][i>>1];}
			 for(int i = 9; i < 16; i+=2){ bal_bank4_temp2_frm.Data[i-8] = bal_temp[3][i>>1]>>8;}
			 for(int i = 16; i < 24; i+=2){ bal_bank4_temp3_frm.Data[i-16] = bal_temp[3][i>>1];}
			 for(int i = 17; i < 24; i+=2){ bal_bank4_temp3_frm.Data[i-16] = bal_temp[3][i>>1]>>8;}
			 for(int i = 24; i < 28; i+=2){ bal_bank4_temp4_frm.Data[i-24] = bal_temp[3][i>>1];}
			 for(int i = 25; i < 28; i+=2){ bal_bank4_temp4_frm.Data[i-24] = bal_temp[3][i>>1]>>8;}

			 for(int i = 0; i < 8; i+=2){ bal_bank5_temp1_frm.Data[i] = bal_temp[4][i>>1];}
			 for(int i = 1; i < 8; i+=2){ bal_bank5_temp1_frm.Data[i] = bal_temp[4][i>>1]>>8;}
			 for(int i = 8; i < 16; i+=2){ bal_bank5_temp2_frm.Data[i-8] = bal_temp[4][i>>1];}
			 for(int i = 9; i < 16; i+=2){ bal_bank5_temp2_frm.Data[i-8] = bal_temp[4][i>>1]>>8;}
			 for(int i = 16; i < 24; i+=2){ bal_bank5_temp3_frm.Data[i-16] = bal_temp[4][i>>1];}
			 for(int i = 17; i < 24; i+=2){ bal_bank5_temp3_frm.Data[i-16] = bal_temp[4][i>>1]>>8;}
			 for(int i = 24; i < 28; i+=2){ bal_bank5_temp4_frm.Data[i-24] = bal_temp[4][i>>1];}
			 for(int i = 25; i < 28; i+=2){ bal_bank5_temp4_frm.Data[i-24] = bal_temp[4][i>>1]>>8;}


			 //Formatting Temperatures
			 for(int i = 0; i < 8; i+=2){ temp_bank1_cell1_frm.Data[i] = cell_temp[0][i>>1];}
			 for(int i = 1; i < 8; i+=2){ temp_bank1_cell1_frm.Data[i] = cell_temp[0][i>>1]>>8;}
			 for(int i = 8; i < 16; i+=2){temp_bank1_cell2_frm.Data[i-8] = cell_temp[0][i>>1];}
			 for(int i = 9; i < 16; i+=2){ temp_bank1_cell2_frm.Data[i-8] = cell_temp[0][i>>1]>>8;}
			 for(int i = 16; i < 20; i+=2){ temp_bank1_cell3_frm.Data[i-16] = cell_temp[0][i>>1];}
			 for(int i = 17; i < 20; i+=2){ temp_bank1_cell3_frm.Data[i-16] = cell_temp[0][i>>1]>>8;}

			 for(int i = 0; i < 8; i+=2){ temp_bank2_cell1_frm.Data[i] = cell_temp[1][i>>1];}
			 for(int i = 1; i < 8; i+=2){ temp_bank2_cell1_frm.Data[i] = cell_temp[1][i>>1]>>8;}
			 for(int i = 8; i < 16; i+=2){temp_bank2_cell2_frm.Data[i-8] = cell_temp[1][i>>1];}
			 for(int i = 9; i < 16; i+=2){ temp_bank2_cell2_frm.Data[i-8] = cell_temp[1][i>>1]>>8;}
			 for(int i = 16; i < 20; i+=2){ temp_bank2_cell3_frm.Data[i-16] = cell_temp[1][i>>1];}
			 for(int i = 17; i < 20; i+=2){ temp_bank2_cell3_frm.Data[i-16] = cell_temp[1][i>>1]>>8;}

			 for(int i = 0; i < 8; i+=2){ temp_bank3_cell1_frm.Data[i] = cell_temp[2][i>>1];}
			 for(int i = 1; i < 8; i+=2){ temp_bank3_cell1_frm.Data[i] = cell_temp[2][i>>1]>>8;}
			 for(int i = 8; i < 16; i+=2){temp_bank3_cell2_frm.Data[i-8] = cell_temp[2][i>>1];}
			 for(int i = 9; i < 16; i+=2){ temp_bank3_cell2_frm.Data[i-8] = cell_temp[2][i>>1]>>8;}
			 for(int i = 16; i < 20; i+=2){ temp_bank3_cell3_frm.Data[i-16] = cell_temp[2][i>>1];}
			 for(int i = 17; i < 20; i+=2){ temp_bank3_cell3_frm.Data[i-16] = cell_temp[2][i>>1]>>8;}

			 for(int i = 0; i < 8; i+=2){ temp_bank4_cell1_frm.Data[i] = cell_temp[3][i>>1];}
			 for(int i = 1; i < 8; i+=2){ temp_bank4_cell1_frm.Data[i] = cell_temp[3][i>>1]>>8;}
			 for(int i = 8; i < 16; i+=2){temp_bank4_cell2_frm.Data[i-8] = cell_temp[3][i>>1];}
			 for(int i = 9; i < 16; i+=2){ temp_bank4_cell2_frm.Data[i-8] = cell_temp[3][i>>1]>>8;}
			 for(int i = 16; i < 20; i+=2){ temp_bank4_cell3_frm.Data[i-16] = cell_temp[3][i>>1];}
			 for(int i = 17; i < 20; i+=2){ temp_bank4_cell3_frm.Data[i-16] = cell_temp[3][i>>1]>>8;}

			 for(int i = 0; i < 8; i+=2){ temp_bank5_cell1_frm.Data[i] = cell_temp[4][i>>1];}
			 for(int i = 1; i < 8; i+=2){ temp_bank5_cell1_frm.Data[i] = cell_temp[4][i>>1]>>8;}
			 for(int i = 8; i < 16; i+=2){temp_bank5_cell2_frm.Data[i-8] = cell_temp[4][i>>1];}
			 for(int i = 9; i < 16; i+=2){ temp_bank5_cell2_frm.Data[i-8] = cell_temp[4][i>>1]>>8;}
			 for(int i = 16; i < 20; i+=2){ temp_bank5_cell3_frm.Data[i-16] = cell_temp[4][i>>1];}
			 for(int i = 17; i < 20; i+=2){ temp_bank5_cell3_frm.Data[i-16] = cell_temp[4][i>>1]>>8;}

			 OSMutexPost(&Temperature_Mutex,OS_OPT_POST_NONE,&CAN1_TX_ERR);
			 if(CAN1_TX_ERR != OS_ERR_NONE)
			 	{ UCOS_Print("TxTask give temperature mutex error\n");}
		 }

		 if(now - TIMING_TICK3 >= 150*OS_CFG_TICK_RATE_HZ/1000)
		 {
				OSMutexPend(&Controlvariable_Mutex, 0, OS_OPT_PEND_BLOCKING, 0, &CAN1_TX_ERR);
				if(CAN1_TX_ERR != OS_ERR_NONE)
					{ UCOS_Print("TxTask take controlvariable mutex error\n");}
				//Formatting SC frame
				sc = 0;
				sc |= (!IMD_Latched())<<0;
				sc |= (!AMS_Latched())<<1;
				sc |= (SC_HVDC_IL())<<2;
				sc |= (SC_END())<<3;
				sc_frm.Data[0] = sc;   //Loaded with SC flag register.

				//Formatting status frame
				status = 0;
				status |= (AMS_state == IdleState || AMS_state == SCEnableRelayState)<<0;
				status |= (AMS_state == ChargeState)<<1;
				status |= (AMS_state == SCEnableState || AMS_state == PrechargeRelay1State || AMS_state == PrechargeRelay2State)<<2;
				status |= (AMS_state == PrechargeState || AMS_state == PrechargeDoneRelayState)<<3;
				status |= (AMS_state == DriveState)<<4;
				status |= (AIRM_AUX())<<5;
				status |= (AIRP_AUX())<<6;
				status |= (Precharge_AUX())<<7;
				status_frm.Data[0] = status;
				status_frm.Data[1] = AMS_flags;
				status_frm.Data[1] |= ((charge_ready && !balance_enable) << 4);

				status_frm.Data[4] = error_flags & 0xff;
				status_frm.Data[5] = error_flags >> 8;

				error_flags = 0;

				OSMutexPost(&Controlvariable_Mutex,OS_OPT_POST_NONE,&CAN1_TX_ERR);
				if(CAN1_TX_ERR != OS_ERR_NONE)
					{ UCOS_Print("TxTask give controlvariable mutex error\n");}
		 }

			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&data_frm, sizeof(CANFRM));  // current frame

			  if(now - TIMING_TICK1 >= 1000*OS_CFG_TICK_RATE_HZ/1000)
			  {
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&soc_frm, sizeof(CANFRM));

			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&bank_voltages1_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&bank_voltages2_frm, sizeof(CANFRM));

			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&cellbank1_voltages1_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&cellbank1_voltages2_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&cellbank1_voltages3_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&cellbank1_voltages4_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&cellbank2_voltages1_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&cellbank2_voltages2_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&cellbank2_voltages3_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&cellbank2_voltages4_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&cellbank3_voltages1_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&cellbank3_voltages2_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&cellbank3_voltages3_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&cellbank3_voltages4_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&cellbank4_voltages1_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&cellbank4_voltages2_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&cellbank4_voltages3_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&cellbank4_voltages4_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&cellbank5_voltages1_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&cellbank5_voltages2_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&cellbank5_voltages3_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&cellbank5_voltages4_frm, sizeof(CANFRM));

			  TIMING_TICK1 = OSTimeGet (&CAN1_TX_ERR);
			  }

			  if(now - TIMING_TICK2 >= 1000*OS_CFG_TICK_RATE_HZ/1000)  // these are the signals that need 1000 ms intervals.
			  {

			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&temp_bank1_cell1_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&temp_bank1_cell2_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&temp_bank1_cell3_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&temp_bank2_cell1_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&temp_bank2_cell2_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&temp_bank2_cell3_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&temp_bank3_cell1_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&temp_bank3_cell2_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&temp_bank3_cell3_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&temp_bank4_cell1_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&temp_bank4_cell2_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&temp_bank4_cell3_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&temp_bank5_cell1_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&temp_bank5_cell2_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&temp_bank5_cell3_frm, sizeof(CANFRM));

			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&bal_bank1_temp1_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&bal_bank1_temp2_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&bal_bank1_temp3_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&bal_bank1_temp4_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&bal_bank2_temp1_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&bal_bank2_temp2_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&bal_bank2_temp3_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&bal_bank2_temp4_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&bal_bank3_temp1_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&bal_bank3_temp2_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&bal_bank3_temp3_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&bal_bank3_temp4_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&bal_bank4_temp1_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&bal_bank4_temp2_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&bal_bank4_temp3_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&bal_bank4_temp4_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&bal_bank5_temp1_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&bal_bank5_temp2_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&bal_bank5_temp3_frm, sizeof(CANFRM));
			  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&bal_bank5_temp4_frm, sizeof(CANFRM));

			  TIMING_TICK2 = OSTimeGet (&CAN1_TX_ERR);
			  }

			  if(now - TIMING_TICK3 >= 150*OS_CFG_TICK_RATE_HZ/1000)  // these are the signals that need 1000 ms intervals.
			  {
				  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&status_frm, sizeof(CANFRM));  // current frame
				  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&sc_frm, sizeof(CANFRM));
				  TIMING_TICK3 = OSTimeGet (&CAN1_TX_ERR);
			  }

			  if(reset_flag)
				  {
				  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&Set_mode_stop_frm, sizeof(CANFRM));
				  OSTimeDlyHMSM (0,0,0,3,OS_OPT_TIME_HMSM_STRICT,&CAN1_TX_ERR);
				  CanBusWrite(ZC7xxx_CAN_BUS_0, (void *)&Restart_frm, sizeof(CANFRM));
				  reset_flag = 0;
				  }

				 OSTimeDly(50*OS_CFG_TICK_RATE_HZ/1000,
						   OS_OPT_TIME_PERIODIC,
						   &CAN1_TX_ERR);
				 if(CAN1_TX_ERR != OS_ERR_NONE)
				 	 UCOS_Print("TxTask delay error\n");


	 }
 }

 void CAN_init(void)
{
	 /*
	 //CAN_Shunt_Task();

	     OSTaskCreate(&CAN1_RX_TCB,                      //  - RX Task.
	                  "CAN1 RX Task",
	 				 CAN1_RxTask,
	 				 0,          				//argument for task. None for the moment
	 				 CAN1_RX_TASK_PRIO,
	 				 &CAN1_RxTaskStk[0],
	 				 CAN1_RX_TASK_STK_SIZE/10,
	 				 CAN1_RX_TASK_STK_SIZE,
	 				 CAN1_RX_TASK_MSGQ_SIZE,
	 				 0,
	 				 DEF_NULL,
	 				 (OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR), //stack checking and stack clearing options
	 				 &CAN1_RX_ERR);

	     OSTaskCreate(&CAN1_TX_TCB,                       //  - TX Task.
	                  "CAN1 TX Task",
	 				 CAN1_TxTask,                       //"CAN_Startup"? "App_CAN_Startup"? "MainTask"?
	 				 0, 						//argument for task. None in this case
	 				 CAN1_TX_TASK_PRIO,
	 				 &CAN1_TxTaskStk[0],
	 				 CAN1_TX_TASK_STK_SIZE/10,
	 				 CAN1_TX_TASK_STK_SIZE,
	 				 CAN1_TX_TASK_MSGQ_SIZE,
	 				 0,
	 				 DEF_NULL,
	 				 (OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
	 				 &CAN1_TX_ERR);

	 				 */


    CPU_INT16S  can_err;
    ZC7xxx_CAN_BSP_IntVectSet();                                // Assign ISR handlers for CAN Channels

    CanSigInit(0L);                                             // Initialize uC/CAN Signals
    CanMsgInit(0L);                                             // Initialize uC/CAN Messages
    CanBusInit(0L);                                             // Initialize uC/CAN Bus

                      // --------------------- CAN 0 ------------------------
    can_err = CanBusEnable((CANBUS_PARA *)&CanCfg0);            // Enable CAN0 Device acc. Configuration
    if (can_err != CAN_ERR_NONE)
        UCOS_Print("Error in CAN0 Bus Enable...\n\r");
    /*
    can_err = CanBusEnable((CANBUS_PARA *)&CanCfg1);
    if (can_err != CAN_ERR_NONE)
        UCOS_Print("Error in CAN1 Bus Enable...\n\r");
*/

}
