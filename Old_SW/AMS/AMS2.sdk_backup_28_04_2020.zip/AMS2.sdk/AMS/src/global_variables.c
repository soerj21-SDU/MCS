/*
 * global_variables.c
 *
 *  Created on: Apr 1, 2020
 *      Author: soeren
 */


#include "global_variables.h"


uint16_t g_cell_voltages[MAX_NUMBER_OF_BANKS][NUMBER_OF_CELLS_PR_BANK]={ 0 };
uint16_t g_lowest_cell_voltage=0;
uint8_t g_higest_cell_temperature=0;
uint8_t g_SOC=0;
uint8_t g_ams_status_heartbeat=0;

