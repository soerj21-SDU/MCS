/*
 * global_variables.h
 *
 *  Created on: Apr 1, 2020
 *      Author: soeren
 */

/*
 * This file contains all the global variable used. The variables are in order
 * of blocks according to the task diagram.
 *
 * Task diagram version: 1.0.1
 */
#ifndef SRC_GLOBAL_VARIABLES_H_
#define SRC_GLOBAL_VARIABLES_H_

#include "stdint.h"
#include "global_def.h"



// General status block
extern uint16_t g_relay_status;
extern uint16_t g_controller_status;

// Cell voltage block
extern uint16_t g_cell_voltages[MAX_NUMBER_OF_BANKS][NUMBER_OF_CELLS_PR_BANK];
extern uint16_t g_lowest_cell_voltage;
extern uint8_t g_higest_cell_temperature; // 1C presition
extern uint8_t g_SOC;
extern uint8_t g_ams_status_heartbeat;

#endif /* SRC_GLOBAL_VARIABLES_H_ */
