/*
 * ControlTask.c
 *
 *  Created on: 26. jun. 2019
 *      Author: matt
 */

#include "ControlTask.h"

#include "AMS_cfg.h"
#include "relay.h"
#include "shutdown.h"
#include "pl_led.h"
#include "tmp100.h"
#include "common.h"

#include "os.h"
#include "xil_printf.h"
#include "stdio.h"
#include "sleep.h"

bool IdleReceived()
{
	return cmd_flags & (1<<0);
}

bool SCEnableReceived()
{
	return cmd_flags & (1<<1);
}

bool PrechargeReceived()
{
	return cmd_flags & (1<<2);
}

bool DriveReceived()
{
	return cmd_flags & (1<<3);
}

bool ChargeReceived()
{
	return cmd_flags & (1<<4);
}

void ControlTask(void *arg)
{
	OS_ERR os_err;

	OS_TICK entered_state_ts = OSTimeGet(&os_err);
	(void)entered_state_ts; // Suppress unused variable warning


	AMS_SC(0); // Close AMS relay as part of initialization. Opens upon error.
	EN_SC(1); // Open Enable relay by default. Closes when receiving enable SC command.

	// Open all TS relays by default.
	AIRM_Control(0);
	AIRP_Control(0);
	Precharge_Control(0);

#ifdef DISCHARGE_TEST
	uint8_t test_discharge_enable = 0;
#endif

	while (1)
	{
		OSMutexPend(&Voltage_Mutex,
				    0,
					OS_OPT_PEND_BLOCKING,
				    0,
					&os_err);
		if(os_err != OS_ERR_NONE)
			xil_printf("ControlTask error taking voltage mutex\r\n");

		OSMutexPend(&Temperature_Mutex,
				    0,
					OS_OPT_PEND_BLOCKING,
				    0,
					&os_err);
		if(os_err != OS_ERR_NONE)
			xil_printf("ControlTask error taking temperature mutex\r\n");

		OSMutexPend(&Controlvariable_Mutex,
				    0,
					OS_OPT_PEND_BLOCKING,
				    0,
					&os_err);
		if(os_err != OS_ERR_NONE)
			xil_printf("ControlTask error taking controlvariable mutex\r\n");

#ifdef DISCHARGE_TEST
		for (uint8_t i = 0; i < 28*bank_count; i++)
		{
			bal_enable[i/28][i%28] = false;
		}

		bal_enable[test_discharge_enable/28][test_discharge_enable%28] = true;
		test_discharge_enable++;
		test_discharge_enable %= 28*bank_count;
		balance_enable = true;
#endif

		// Read ambient temperature
		//master_temp = tmp100_read()/256;

		// Check cell voltage and temperature timestamps
		bool monitor_error = false;
		bool any_voltage_too_high = false;
		bool any_voltage_too_low = false;
		bool any_charge_temp_too_high = false;
		bool any_temp_too_high = false;
		bool any_temp_too_low = false;
		bool shunt_disconnect = false;

		OS_TICK now = OSTimeGet(&os_err);

		for (uint8_t i = 0; i < bank_count; i++)
		{
			for (uint8_t j = 0; j < 28; j++)
			{
				if (now - cell_volt_ts[i][j] + CONTROLTASK_LOOP_TIME_TICKS > VOLT_SAFETY_INTERVAL_TICKS)
				{
					monitor_error = true;
					if (cell_volt[i][j] < VOLT_MIN)
						any_voltage_too_low = true;
					if (cell_volt[i][j] > VOLT_MAX)
						any_voltage_too_high = true;
				}
			}

			for (uint8_t j = 0; j < 10; j++)
			{
				if (now - cell_temp_ts[i][j] + CONTROLTASK_LOOP_TIME_TICKS > TEMP_SAFETY_INTERVAL_TICKS)
				{
					monitor_error = true;
					if (cell_temp[i][j] < TEMP_MIN)
						any_temp_too_low = true;
					if (cell_temp[i][j] > TEMP_MAX)
						any_temp_too_high = true;
				}

				if (AMS_state == ChargeState && now - cell_charge_temp_ts[i][j] + CONTROLTASK_LOOP_TIME_TICKS > TEMP_SAFETY_INTERVAL_TICKS)
				{
					monitor_error = true;
					if (cell_temp[i][j] < TEMP_MIN)
						any_temp_too_low = true;
					if (cell_temp[i][j] > TEMP_CHARGE_MAX)
						any_charge_temp_too_high = true;
				}
			}
		}


		error_flags |= (any_voltage_too_low << 0);
		error_flags |= (any_voltage_too_high << 1);
		error_flags |= (any_temp_too_low << 2);
		if (AMS_state == ChargeState)
		{
			error_flags |= (any_charge_temp_too_high << 3);
		}
		else
		{
			error_flags |= (any_temp_too_high << 3);
		}
		error_flags |= (any_LTC6813_error << 4);

		OSMutexPost(&Voltage_Mutex,
				  OS_OPT_POST_NONE,
				  &os_err);
		if(os_err != OS_ERR_NONE)
			xil_printf("ControlTask error giving voltage mutex\r\n");

		OSMutexPost(&Temperature_Mutex,
				  OS_OPT_POST_NONE,
				  &os_err);
		if(os_err != OS_ERR_NONE)
			xil_printf("ControlTask error giving temperature mutex\r\n");

		OSMutexPend(&Power_Mutex,
				    0,
					OS_OPT_PEND_BLOCKING,
				    0,
					&os_err);
		if(os_err != OS_ERR_NONE)
			xil_printf("ControlTask error taking power mutex\r\n");

		now = OSTimeGet(&os_err);
		if (now - shunt_battery_volt_ts     + CONTROLTASK_LOOP_TIME_TICKS > SHUNT_SAFETY_INTERVAL_TICKS)
		{
			shunt_disconnect = true;
			//xil_printf("shunt battery volt ts | %d | %d \r\n", now, shunt_battery_volt_ts);
		}

		now = OSTimeGet(&os_err);
		if (now - shunt_precharge_volt_ts   + CONTROLTASK_LOOP_TIME_TICKS > SHUNT_SAFETY_INTERVAL_TICKS)
		{
			shunt_disconnect = true;
			//xil_printf("shunt precharge volt ts | %d | %d \r\n", now, shunt_precharge_volt_ts);
		}

		now = OSTimeGet(&os_err);
		if (now - shunt_curr_ts             + CONTROLTASK_LOOP_TIME_TICKS > SHUNT_SAFETY_INTERVAL_TICKS)
		{
			shunt_disconnect = true;
			//xil_printf("shunt current ts | %d | %d \r\n", now, shunt_curr_ts);
		}

		now = OSTimeGet(&os_err);
		if (now - shunt_power_ts            + CONTROLTASK_LOOP_TIME_TICKS > SHUNT_SAFETY_INTERVAL_TICKS)
		{
			shunt_disconnect = true;
			//xil_printf("shunt power ts | %d | %d \r\n", now, shunt_power_ts);
		}

		now = OSTimeGet(&os_err);
		if (now - shunt_coulomb_counter_ts + CONTROLTASK_LOOP_TIME_TICKS > 5000)
		{
			shunt_disconnect = true;
			//xil_printf("shunt coulomb counter ts | %d | %d \r\n", now, shunt_coulomb_counter_ts);
		}

		now = OSTimeGet(&os_err);
		if (now - shunt_energy_counter_ts   + CONTROLTASK_LOOP_TIME_TICKS > 5000)
		{
			shunt_disconnect = true;
			//xil_printf("shunt energy counter ts | %d | %d \r\n", now, shunt_energy_counter_ts);
		}

		OSMutexPost(&Power_Mutex,
				    OS_OPT_POST_NONE,
				    &os_err);
		if(os_err != OS_ERR_NONE)
			xil_printf("ControlTask error giving power mutex\r\n");

		error_flags |= (shunt_disconnect << 5);

		//*
		if (any_LTC6813_error)
		{
			xil_printf("LTC6813 error for:");
			for (uint8_t i = 0; i < bank_count*2; i++)
			{
				if (LTC6813_error[i])
					xil_printf(" %d", i);
			}
			xil_printf("\r\n");
		}
		//*/

		if (monitor_error || shunt_disconnect)
		{
			AMS_SC(1);
			AMS_state = IdleState;
			entered_state_ts = OSTimeGet(&os_err);
		}
		else
		{
			AMS_SC(0);
		}

		if (monitor_error)
		{
			xil_printf("Monitor error\r\n");
		}

		if (shunt_disconnect)
		{
			xil_printf("Shunt disconnect\r\n");
		}

		// Safety checks for charger voltage level
		if (connected_to_charger)
		{
			if (shunt_precharge_volt < sum_of_all_cells ||
				shunt_precharge_volt < 28*bank_count*VOLT_MIN ||
				shunt_precharge_volt > 28*bank_count*VOLT_MAX)
			{
				AMS_SC(1);
				AMS_state = IdleState;
				entered_state_ts = OSTimeGet(&os_err);
				error_flags |= (1 << 13);
				xil_printf("Error ID 13\r\n");
			}
		}

		// State machine
		if (IdleReceived() && AMS_state != IdleState)
		{
			cmd_flags = 0;
			AMS_state = IdleState;
			entered_state_ts = OSTimeGet(&os_err);
			xil_printf("Idle command received!\r\n");
		}

		if (SC_END() == 0 && (AMS_state != IdleState && AMS_state != SCEnableRelayState))
		{
			cmd_flags = 0;
			AMS_state = IdleState;
			entered_state_ts = OSTimeGet(&os_err);
		}

		bool update_state = true;

		while (update_state)
		{
			update_state = false;

			now = OSTimeGet(&os_err);
			switch (AMS_state)
			{
			case IdleState:
				pl_leds_set(0b000);
				EN_SC(0);
				Precharge_Control(0);
				AIRP_Control(0);
				AIRM_Control(0);

				AMS_flags = 0;

				if ((now - entered_state_ts > RELAY_DELAY_TICKS) && SC_END())
				{
					AMS_SC(1);
					error_flags |= (1 << 6);
					xil_printf("Error ID 6\r\n");
				}

				if ((now - entered_state_ts > RELAY_DELAY_TICKS) && (Precharge_AUX() == 0 || AIRP_AUX() == 0 || AIRM_AUX() == 0))
				{
					AMS_SC(1);
					error_flags |= (1 << 7);
					xil_printf("Error ID 7\r\n");
				}

				if (SCEnableReceived() && SC_IN_Again())
				{
					AMS_state = SCEnableRelayState;
					entered_state_ts = OSTimeGet(&os_err);
					update_state = true;
				}
				break;

			case SCEnableRelayState:
				pl_leds_set(0b000);
				EN_SC(1);
				Precharge_Control(0);
				AIRP_Control(0);
				AIRM_Control(0);

				if (now - entered_state_ts > RELAY_DELAY_TICKS)
				{
					if (SC_END())
					{
						AMS_state = SCEnableState;
						entered_state_ts = OSTimeGet(&os_err);
						update_state = true;
					}
					else
					{
						AMS_state = IdleState;
						entered_state_ts = OSTimeGet(&os_err);
						update_state = true;
						AMS_SC(1);
						error_flags |= (1 << 8);
						xil_printf("Error ID 8\r\n");
					}
				}

				break;

			case SCEnableState:
				pl_leds_set(0b001);
				EN_SC(1);
				Precharge_Control(0);
				AIRP_Control(0);
				AIRM_Control(0);

				AMS_flags |= 1;

				if (Precharge_AUX() == 0 || AIRP_AUX() == 0 || AIRM_AUX() == 0)
				{
					AMS_state = IdleState;
					entered_state_ts = OSTimeGet(&os_err);
					update_state = true;
					AMS_SC(1);
					xil_printf("This error has no error ID as it shouldn't be able to happen\r\n");
				}

				if (PrechargeReceived())
				{
					AMS_state = PrechargeRelay1State;
					entered_state_ts = OSTimeGet(&os_err);
					update_state = true;
				}
				break;

			case PrechargeRelay1State:
				pl_leds_set(0b010);
				EN_SC(1);
				Precharge_Control(1);
				AIRP_Control(0);
				AIRM_Control(0);

				if (now - entered_state_ts > RELAY_DELAY_TICKS)
				{
					if (Precharge_AUX() == 0 && AIRP_AUX() == 1 && AIRM_AUX() == 1)
					{
						AMS_state = PrechargeRelay2State;
						entered_state_ts = OSTimeGet(&os_err);
						update_state = true;
					}
					else
					{
						AMS_state = IdleState;
						entered_state_ts = OSTimeGet(&os_err);
						update_state = true;
						AMS_SC(1);
						error_flags |= (1 << 9);
						xil_printf("Error ID 9 1\r\n");
					}
				}

				break;

			case PrechargeRelay2State:
				pl_leds_set(0b010);
				EN_SC(1);
				Precharge_Control(1);
				AIRP_Control(0);
				AIRM_Control(1);

				if (now - entered_state_ts > RELAY_DELAY_TICKS)
				{
					if (Precharge_AUX() == 0 && AIRP_AUX() == 1 && AIRM_AUX() == 0)
					{
						AMS_state = PrechargeState;
						entered_state_ts = OSTimeGet(&os_err);
						update_state = true;
						shunt_battery_volt_updated = false;
						shunt_precharge_volt_updated = false;
					}
					else
					{
						AMS_state = IdleState;
						entered_state_ts = OSTimeGet(&os_err);
						update_state = true;
						AMS_SC(1);
						error_flags |= (1 << 9);
						xil_printf("Error ID 9 2\r\n");
					}
				}

				break;

			case PrechargeState:
				pl_leds_set(0b011);
				EN_SC(1);
				Precharge_Control(1);
				AIRP_Control(0);
				AIRM_Control(1);

				if (now - entered_state_ts > PRECHARGE_TIMEOUT_TICKS)
				{
					AMS_state = IdleState;
					entered_state_ts = OSTimeGet(&os_err);
					update_state = true;
					AMS_SC(1);
					error_flags |= (1 << 11);
					xil_printf("Error ID 11\r\n");
				}

				if (shunt_battery_volt_updated &&
				    shunt_precharge_volt_updated &&
				    now - entered_state_ts > (1000 - RELAY_DELAY_TICKS) &&
				    shunt_precharge_volt > shunt_battery_volt*0.95 &&
				    shunt_precharge_volt < shunt_battery_volt*1.05)
				//if (now - entered_state_ts > 4500)
				{
					AMS_state = PrechargeDoneRelayState;
					entered_state_ts = OSTimeGet(&os_err);
					update_state = true;
					// Shortened to make it print faster
					xil_printf("Prech done w/\r\nBatt volt = %d mV\r\nPrech volt = %d mV\r\n",
							shunt_battery_volt,
							shunt_precharge_volt);
				}
				break;

			case PrechargeDoneRelayState:
				pl_leds_set(0b100);
				EN_SC(1);
				Precharge_Control(0);
				AIRP_Control(1);
				AIRM_Control(1);

				AMS_flags |= (1 << 1);

				if (now - entered_state_ts > RELAY_DELAY_TICKS)
				{
					if (Precharge_AUX() == 1 && AIRP_AUX() == 0 && AIRM_AUX() == 0)
					{
						AMS_state = PrechargeDoneState;
						entered_state_ts = OSTimeGet(&os_err);
						update_state = true;
					}
					else
					{
						AMS_state = IdleState;
						entered_state_ts = OSTimeGet(&os_err);
						update_state = true;
						AMS_SC(1);
						error_flags |= (1 << 10);
						xil_printf("Error ID 10\r\n");
					}
				}

				break;

			case PrechargeDoneState:
				pl_leds_set(0b101);
				EN_SC(1);
				Precharge_Control(0);
				AIRP_Control(1);
				AIRM_Control(1);

				AMS_flags |= (1 << 2);

				if (DriveReceived())
				{
					AMS_state = DriveState;
					entered_state_ts = OSTimeGet(&os_err);
					update_state = true;
				}

				if (ChargeReceived())
				{
					AMS_state = ChargeState;
					entered_state_ts = OSTimeGet(&os_err);
					update_state = true;
				}
				break;

			case DriveState:
				pl_leds_set(0b110);
				EN_SC(1);
				Precharge_Control(0);
				AIRP_Control(1);
				AIRM_Control(1);
				break;

			case ChargeState:
				pl_leds_set(0b111);
				EN_SC(1);
				Precharge_Control(0);
				AIRP_Control(1);
				AIRM_Control(1);

				if (charge_ready)
				{
					AMS_flags |= (1 << 3);
				}

				if (charge_finished)
				{
					AMS_state = IdleState;
					entered_state_ts = OSTimeGet(&os_err);
					update_state = true;
				}
				break;

			default:
				xil_printf("AMS IN UNHANDLED STATE\r\n");
				break;
			}
		}

		cmd_flags = 0;

		OSMutexPost(&Controlvariable_Mutex,
				  OS_OPT_POST_NONE,
				  &os_err);
		if(os_err != OS_ERR_NONE)
			xil_printf("ControlTask error giving controlvariable mutex\r\n");

		 OSTimeDly(CONTROLTASK_LOOP_TIME_TICKS,
				   OS_OPT_TIME_PERIODIC,
				   &os_err);
		 if(os_err != OS_ERR_NONE)
		 	 xil_printf("ControlTask delay error\r\n");
	}
}
