/*
 * CAN_Tx_Task.h
 *
 *  Created on: Apr 1, 2020
 *      Author: soeren
 */

#ifndef SRC_TASKS_CAN_TX_TASK_H_
#define SRC_TASKS_CAN_TX_TASK_H_

#include  <can_frm.h>
#include  <can_bus.h>
#include "../common.h"
#include "../global_def.h"
#include <Source/os.h>
#include <stdlib.h>
#include <app_cfg.h>
#include <can_cfg.h>
#include <can_bsp.h>
#include "can_sig.h"
#include "can_msg.h"
#include "can_err.h"
#include "drv_can.h"
//#include "cpu.h"
//#include "AMSControl.h"
#include  <can_frm.h>
#include  <can_bus.h>

#include "../relay.h"
#include "../shutdown.h"
#include "../global_variables.h"


#define  CAN_TX_TASK_PRIO                         2u
#define  CAN_TX_TASK_STK_SIZE                     512u
#define  CAN_TX_TASK_MSGQ_SIZE					   32u

extern  const CANBUS_PARA  CanCfg0;
extern const  CANMSG_PARA  CanMsg[CANMSG_N];

OS_TCB CAN_TX_TCB;
CPU_STK  CAN_TxTaskStk[CAN_TX_TASK_STK_SIZE];


OS_ERR create_CAN_TX_Task();
void CAN_TX_Task(void *arg);
void CAN_Init();


#endif /* SRC_TASKS_CAN_TX_TASK_H_ */
