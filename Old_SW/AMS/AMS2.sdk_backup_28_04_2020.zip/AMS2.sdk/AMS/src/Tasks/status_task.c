/*
 * status_task.c
 *
 *  Created on: Mar 18, 2020
 *      Author: soeren
 */

#include "status_task.h"

#include <Source/os.h>
#include "os.h"
#include "xil_printf.h"
#include "xcanps.h"
#include "stdlib.h"

#include "../AMS_cfg.h"
#include "../common.h"
#include "../dac.h"
#include "../relay.h"

#include "../shutdown.h"
#include "../tmp100.h"
#include "../global_def.h"

#include "../Unit_testing/unity.h"



OS_ERR Status_CreateTask()
{
	OS_ERR error;
	OSTaskCreate(
			&STATUS_TCB,
			"Status DEBUG Task",
			Status_Task,
			NULL,
			STATUS_TASK_PRIO,
			&STATUS_TaskStk[0],
			STATUS_TASK_STK_SIZE / 10,
			STATUS_TASK_STK_SIZE,
			STATUS_TASK_MSGQ_SIZE,
			0,
			DEF_NULL,
			(OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR),
			&error
			);

	return error;

}



void Status_Task(void *arg)
{

	OS_ERR err;
	uint8_t counter =0;

	UCOS_Print("Status Task started\r\n");
	while(1)
	{


		OSTimeDlyHMSM(0,0,1,0,OS_OPT_TIME_HMSM_STRICT,&err); // delay 1 sec


			counter++;
			xil_printf("\E[H\E[J"); // Reset terminal
			UCOS_Printf("Counter = %d \r\n",counter);
			UCOS_Printf("TX alive  = %d \r\n",g_CAN_TX_Alive_Counter);

			UCOS_Printf("Safety Curcit: \r\n");
			//xil_printf("IMD_SWITCH = %d\r\n",IMD_Status());
			UCOS_Printf("IMD_Switch = %d | IMD_Latched = %d | IMD_Data = %d | AMS_Latched = %d | SC_IN = %d | SC_HVDC_IL = %d | SC_IN_Again = %d | SC_END = %d\r\n",
						IMD_Status(), IMD_Latched(), IMD_Data(), AMS_Latched(), SC_IN(), SC_HVDC_IL(), SC_IN_Again(), SC_END());

			UCOS_Printf("---\r\n");
			UCOS_Printf("AUX Relays: \r\n");
			UCOS_Printf("Precharge = %d, AIR+ = %d, AIR- = %d \r\n",Precharge_AUX(),AIRP_AUX(),AIRM_AUX());


			uint8_t relay_out = get_relay_out();

			bool Precharge_out = relay_out & (1 << 0);
			bool AIRP_out = relay_out & (1 << 1);
			bool AIRM_out = relay_out & (1 << 2);

			UCOS_Printf("Relay out: \r\n");
			UCOS_Printf("Precharge = %d, AIR+ = %d, AIR- = %d \r\n",Precharge_out,AIRP_out,AIRM_out);

			UCOS_Printf("cmd_flags: %d \r\n",command_signal);
			bool bit7= command_signal & (1<<7);
			bool bit6= command_signal & (1<<6);
			bool bit5= command_signal & (1<<5);
			bool bit4= command_signal & (1<<4);
			bool bit3= command_signal & (1<<3);
			bool bit2= command_signal & (1<<2);
			bool bit1= command_signal & (1<<1);
			bool bit0= command_signal & (1<<0);
			UCOS_Printf("%d %d %d %d %d %d %d %d \r\n",bit7,bit6,bit5,bit4,bit3,bit2,bit1,bit0);


			// print chart state

			UCOS_Printf("Stateflow state: ");
			switch (Control_states) {
				case ControlState_T_Init_state:
					UCOS_Printf("Init");
					break;
				case ControlState_T_Idle:
					UCOS_Printf("Idle");
					break;
				case ControlState_T_SC_enable:
					UCOS_Printf("SC  enable");
					break;
				case ControlState_T_SC_enabled:
					UCOS_Printf("SC enabled");
					break;
				case ControlState_T_Close_AIR_m:
					UCOS_Printf("Close AIR-");
					break;
				case ControlState_T_Close_Pre:
					UCOS_Printf("Close Precharge");
					break;
				case ControlState_T_Precharnig:
					UCOS_Printf("Prexcharging");
					break;
				case ControlState_T_Open_Pre:
					UCOS_Printf("Open Precharge");
					break;
				case ControlState_T_Close_AIR_p:
					UCOS_Printf("Close AIR+");
					break;
				case ControlState_T_TS_active:
					UCOS_Printf("TS active");
					break;
				case ControlState_T_Error:
					UCOS_Printf("Error state");
					break;
				case ControlState_T_Drive:
					UCOS_Printf("Drive");
					break;
				case ControlState_T_None:
					UCOS_Printf("NONE");
					break;
				case ControlState_T_Init_charing: // Start her
					UCOS_Printf("Init charging");
					break;
				case ControlState_T_C_Close_AIR_m:
					UCOS_Printf("Charging: Close AIR-");
					break;
				case ControlState_T_Charger_Error:
					UCOS_Printf("Charging: Error");
					break;
				case ControlState_T_C_Close_Pre:
					UCOS_Printf("Charging: close precharge");
					break;
				case ControlState_T_C_Precharnig:
					UCOS_Printf("Charging: Precharging");
					break;
				case ControlState_T_C_Open_Pre:
					UCOS_Printf("Charging: Open Precharge");
					break;
				case ControlState_T_C_Close_AIR_p:
					UCOS_Printf("Charging: Close AIR+");
					break;
				case ControlState_T_Charge_Algortihm:
					UCOS_Printf("Charging: Charge algorithm");
					break;
				case ControlState_T_C_Open_AIR_p:
					UCOS_Printf("Charging Done: Open AIR+");
					break;
				case ControlState_T_C_Open_AIR_m:
					UCOS_Printf("Charging Done: Open AIR-");
					break;
				case ControlState_T_Error_lached:
					UCOS_Printf("Error latched");
					break;
				case ControlState_T_Charger_Error_lached:
					UCOS_Printf("Charger Error latched");
					break;
				default:
					UCOS_Printf("Unknown");
					break;
			}
			UCOS_Printf("\r\n");

			// Errors

			UCOS_Printf("Controller Errors: %d , SC_BROKN = %d \r\n",Control_Errors,Control_Errors & (1<<E_AMS_SC_BROKEN));


			if(Control_Errors & (1<<E_AMS_UNABLE_TO_CLOSE_AIR_M)) UCOS_Printf("Error: AIR - could not close\r\n");
			if(Control_Errors & (1<<E_AMS_UNABLE_TO_CLOSE_PRE)) UCOS_Printf("Error: Precharge could not close\r\n");
			if(Control_Errors & (1<<E_AMS_UNABLE_TO_CLOSE_AIR_P)) UCOS_Printf("Error: AIR+ could not close\r\n");
			if(Control_Errors & (1<<E_AMS_RELAY_FAIELD)) UCOS_Printf("Error: Relay failed during TS/Drive mode\r\n");
			if(Control_Errors & (1<<E_AMS_UNABLE_TO_OPEN_PRE)) UCOS_Printf("Error: Precharge could not open\r\n");
			if(Control_Errors & (1<<E_AMS_UNEXCEPTED_TS_CURRENT)) UCOS_Printf("Error: Unexcepted TS current\r\n");
			if(Control_Errors & (1<<E_AMS_PRE_TIMEOUT)) UCOS_Printf("Error: Precharge timeout\r\n");
			if(Control_Errors & (1<<E_AMS_UNABLE_TO_CLOSE_SC)) UCOS_Printf("Error: Could not close Safety chain \r\n");
			if(Control_Errors & (1<<E_AMS_SC_BROKEN)) UCOS_Printf("Error: Safety chain broken \r\n");
			if(Control_Errors & (1<<E_AMS_UNABLE_TO_OPEN_AIR_M)) UCOS_Printf("Error: Unable to open AIR-\r\n");
			if(Control_Errors & (1<<E_AMS_UNABLE_TO_OPEN_AIR_P)) UCOS_Printf("Error:Unable to open AIR+ \r\n");
			if(Control_Errors & (1<<E_AMS_UNFIT_CHARGE_VOLTAGE)) UCOS_Printf("Error: Unfit charge current  \r\n");
			//UCOS_Printf("Error Event: %d \r\n ",Error_SC_Event );


			/*
			//Run_controller_unit_test();
			UnityBegin("../matlat_import/controller/test_control_statemachine.c");
			UCOS_Printf("UNIT TESTS DEBUG 1: \r\n");
			RUN_TEST(test_controller_should_ResetALLOUTPUTVALUES);
			UnityEnd();
			*/



			//xil_printf("%d %d %d %d %d %d %d %d \r\n", cmd_flags & ~(1<<7),cmd_flags & ~(1<<6),cmd_flags & ~(1<<5),cmd_flags & ~(1<<4),cmd_flags & ~(1<<3),cmd_flags & ~(1<<2),cmd_flags & ~(1<<1),cmd_flags & ~(1<<0));

			// (cmd_flags & ~(1<<7)),cmd_flags & ~(1<<6),cmd_flags & ~(1<<5),cmd_flags & ~(1<<4),cmd_flags & ~(1<<3),cmd_flags & ~(1<<2)cmd_flags & ~(1<<1),cmd_flags & ~(1<<0)


	}

}

/*
while(1)
{


	OSTimeDlyHMSM(0,                             (1)
				  0,
				  1,
				  0,
				  OS_OPT_TIME_HMSM_STRICT,       (2)
				  &err);                         (3)





	now = OSTimeGet(&err);


	if(now - TIMING_TICK1 >= 1000*OS_CFG_TICK_RATE_HZ/1000)
	{


		counter++;
		xil_printf("\E[H\E[J"); // Reset terminal
		UCOS_Printf("Counter = %d \r\n",counter);

		UCOS_Printf("Safety Curcit: \r\n");
		//xil_printf("IMD_SWITCH = %d\r\n",IMD_Status());
		UCOS_Printf("IMD_Switch = %d | IMD_Latched = %d | IMD_Data = %d | AMS_Latched = %d | SC_IN = %d | SC_HVDC_IL = %d | SC_IN_Again = %d | SC_END = %d\r\n",
					IMD_Status(), IMD_Latched(), IMD_Data(), AMS_Latched(), SC_IN(), SC_HVDC_IL(), SC_IN_Again(), SC_END());

		UCOS_Printf("---\r\n");
		UCOS_Printf("AUX Relays: \r\n");
		UCOS_Printf("Precharge = %d, AIR+ = %d, AIR- = %d \r\n",Precharge_AUX(),AIRP_AUX(),AIRM_AUX());


		uint8_t relay_out = get_relay_out();

		bool Precharge_out = relay_out & ~(1 << 0);
		bool AIRP_out = relay_out & ~(1 << 1);
		bool AIRM_out = relay_out & ~(1 << 2);

		UCOS_Printf("Relay out: \r\n");
		UCOS_Printf("Precharge = %d, AIR+ = %d, AIR- = %d \r\n",Precharge_out,AIRP_out,AIRM_out);

		UCOS_Printf("cmd_flags: %d \r\n",cmd_flags);
		bool bit7= cmd_flags & (1<<7);
		bool bit6= cmd_flags & (1<<6);
		bool bit5= cmd_flags & (1<<5);
		bool bit4= cmd_flags & (1<<4);
		bool bit3= cmd_flags & (1<<3);
		bool bit2= cmd_flags & (1<<2);
		bool bit1= cmd_flags & (1<<1);
		bool bit0= cmd_flags & (1<<0);
		UCOS_Printf("%d %d %d %d %d %d %d %d \r\n",bit7,bit6,bit5,bit4,bit3,bit2,bit1,bit0);
		//xil_printf("%d %d %d %d %d %d %d %d \r\n", cmd_flags & ~(1<<7),cmd_flags & ~(1<<6),cmd_flags & ~(1<<5),cmd_flags & ~(1<<4),cmd_flags & ~(1<<3),cmd_flags & ~(1<<2),cmd_flags & ~(1<<1),cmd_flags & ~(1<<0));

		// (cmd_flags & ~(1<<7)),cmd_flags & ~(1<<6),cmd_flags & ~(1<<5),cmd_flags & ~(1<<4),cmd_flags & ~(1<<3),cmd_flags & ~(1<<2)cmd_flags & ~(1<<1),cmd_flags & ~(1<<0)

		TIMING_TICK1 = OSTimeGet (&err);
	}

}
*/

