/*
 * cell_Com_Task.c
 *
 *  Created on: Apr 8, 2020
 *      Author: soeren
 */


#include "cell_Com_Task.h"


OS_ERR cellCom_CreateTask()
{
	OS_ERR error;

    OSTaskCreate(&g_cell_com_TCP,                      //  - RX Task.
                 "CAN RX Task",
				 CellCom_Task,
				 0,          				//argument for task. None for the moment
				 CELL_COM_TASK_PRIO,
				 &cell_com_task_stk[0],
				 CELL_COM_TASK_STK_SIZE/10,
				 CELL_COM_TASK_STK_SIZE,
				 CELL_COM_TASK_MSGQ_SIZE,
				 0,
				 DEF_NULL,
				 (OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR), //stack checking and stack clearing options
				 &error);

    return error;

}
void CellCom_Task(void *arg)
{
	while(1)
	{

	}
}

