/*
 * monitor_Task.c
 *
 *  Created on: Apr 8, 2020
 *      Author: soeren
 */

#include "monitor_Task.h"


OS_ERR create_monitor_Task()
{
	OS_ERR error;

    OSTaskCreate(&g_monitor_TCP,                      //  - RX Task.
                 "CAN RX Task",
				 Monitor_Task,
				 0,          				//argument for task. None for the moment
				 MONITOR_TASK_PRIO,
				 &monitor_task_stk[0],
				 MONITOR_TASK_STK_SIZE/10,
				 MONITOR_TASK_STK_SIZE,
				 MONITORTX_TASK_MSGQ_SIZE,
				 0,
				 DEF_NULL,
				 (OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR), //stack checking and stack clearing options
				 &error);

    return error;




}
void Monitor_Task(void *arg)
{
	while(1)
	{
		 // Suspend untill signal flag is raised.

		// Take cell voltage semaphore
		// Go through each cell voltages
		// Give semaphore



		// Take cell temp semaphore
		// Go through each cell temp
		// Give cell temp semaphore.

	}

}
