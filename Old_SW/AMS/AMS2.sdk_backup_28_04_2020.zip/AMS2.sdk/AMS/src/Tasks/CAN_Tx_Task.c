/*
 * CAN_Tx_Task.c
 *
 *  Created on: Apr 1, 2020
 *      Author: soeren
 */

#include "CAN_Tx_Task.h"


// Internal functions

void send_frame(CANFRM * frm);
void Send_Status_Message();
void send_status();
uint8_t parse_status_byte1();
void send_cell_voltages(CANFRM *frame, uint8_t bank, uint8_t group);
void CAN_Init()
{
    CPU_INT16S  can_err;
    CANMSG_PARA  *m;
#if (CANSIG_STATIC_CONFIG == 0u)
    CANSIG_PARA  *s;
#endif


    ZC7xxx_CAN_BSP_IntVectSet();                                // Assign ISR handlers for CAN Channels


    CanSigInit(0L);                                          /* Initialize CAN Signals.                              */
#if (CANSIG_STATIC_CONFIG == 0u)
    s = CanSig;
    while (s < &CanSig[S_MAX]) {                                /* Create CAN Signals                                   */
        can_err = CanSigCreate(s);
        if (can_err < 0) {
        	UCOS_Print("Error in CAN0 CAnnot create CAN signals...\n\r");
           while (1);                                           /* Failure Handling Here.                               */
        }
        s++;
    }
#endif
    CanMsgInit(0L);                                          /* Initialize CAN Messages.                             */
    m = (CANMSG_PARA *)CanMsg;
    while (m < &CanMsg[CANMSG_N]) {                          /* Create CAN Messages.                                 */
        can_err = CanMsgCreate(m);
        if (can_err < 0) {
        	UCOS_Print("Error in CAN0 Cannot create CAN messages...\n\r");
           while (1);                                           /* Failure Handling Here.                               */
        }
        m++;
    }


    CanBusInit(0L);                                             // Initialize uC/CAN Bus

                      // --------------------- CAN 0 ------------------------
    can_err = CanBusEnable((CANBUS_PARA *)&CanCfg0);            // Enable CAN0 Device acc. Configuration
    if (can_err != CAN_ERR_NONE)
        UCOS_Print("Error in CAN0 Bus Enable...\n\r");
}
OS_ERR create_CAN_TX_Task()
{
	OS_ERR err;

    OSTaskCreate(&CAN_TX_TCB,                      //  - TX Task.
                 "CAN RX Task",
				 CAN_TX_Task,
				 0,          				//argument for task. None for the moment
				 CAN_TX_TASK_PRIO,
				 &CAN_TxTaskStk[0],
				 CAN_TX_TASK_STK_SIZE/10,
				 CAN_TX_TASK_STK_SIZE,
				 CAN_TX_TASK_MSGQ_SIZE,
				 0,
				 DEF_NULL,
				 (OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR), //stack checking and stack clearing options
				 &err);

    return err;

}

void CAN_TX_Task(void *arg)
{


	g_CAN_TX_Alive_Counter=0;
	OS_ERR err;
	g_ams_status_heartbeat=0;

	CANFRM status_frm;
	status_frm.Identifier = 0x400u;
	status_frm.DLC        = 6u;

	CANFRM cell_voltage_frm;
	cell_voltage_frm.Identifier = 0x401u;
	cell_voltage_frm.DLC        = 8u;
	while(1)
	{
		//g_CAN_TX_Alive_Counter++;



		send_status(&status_frm);

		for(uint8_t bank=1;bank <=5;bank++)
		{
			for(uint8_t group=0; group<=4; group++)
			{
				send_cell_voltages(&cell_voltage_frm,bank,group);
			}
		}


		//send_frame(&status_frm);
		//CanBusWrite(ZC7xxx_CAN_BUS_0,(void*)&status_frm,sizeof(CANFRM)); // Send Frame.
		/* TEST OF SIGNAL AND MESSAGE. MESSAGE OPENING IN SEND_STATUS DOES NOT WORK.
		CanSigWrite(S_CONTROLLER_STATUS,&counter,1); // Update the signal

		Send_Status_Message();
		*/



		OSTimeDlyHMSM(0,0,1,0,OS_OPT_TIME_HMSM_STRICT,&err); // delay 1 sec







	}
}
void send_frame(CANFRM * frm)
{
	CanBusWrite(ZC7xxx_CAN_BUS_0,(void*)frm,sizeof(CANFRM)); // Send Frame.
}

/*
 * input: bank = 1->5
 * input: group = 0-> 4.
 */
void send_cell_voltages(CANFRM *frame, uint8_t bank, uint8_t group)
{
	if(bank>5){
		// Error
		UCOS_Printf("Error in CANTX send voltages: Cannot bank count out of scope");
		return;
	}

	if(bank<=5 && group >= 0 && group <=4)
	{
		uint8_t control_byte = ((bank & 7) <<5) | (group & 7);

		frame->Data[0] = control_byte;

		for( uint8_t i =1; i<=7 ; i++)
		{

			frame->Data[i]=g_cell_voltages[bank-1][(i-1)+(group*7)];
		}

		send_frame(frame);
	}


}


uint8_t parse_status_byte1()
{
	 uint8_t ams_status =(Control_states & 31);

	 uint8_t number_of_banks= ((g_number_of_banks & 7)<<5);

	 return (number_of_banks|ams_status);


}
uint8_t parse_status_byte2()
{

	//UCOS_Printf("Precharge = %d, AIR+ = %d, AIR- = %d \r\n",Precharge_AUX(),AIRP_AUX(),AIRM_AUX());

	uint8_t relays= (AIRM_AUX() << 7) | (AIRP_AUX() << 6) |(Precharge_AUX() << 5);
	uint8_t errors= (IMD_Latched() << 1) | (AMS_Latched()<<0);
	uint8_t warninigs = (g_warining_temprature <<2) | (g_warining_voltage_near_limit <<3);

	 return (relays | errors| warninigs);
	 //return (number_of_banks|ams_status);

	return 0;

}
void send_status(CANFRM *frame)
{

	g_ams_status_heartbeat++;
	uint8_t byte1 = parse_status_byte1();
	uint8_t byte2 = parse_status_byte2();

	frame->Data[0]=byte1;
	frame->Data[1]=byte2;
	frame->Data[2]=(uint8_t) g_lowest_cell_voltage;
	frame->Data[3]=g_higest_cell_temperature;
	frame->Data[4]=g_SOC;
	frame->Data[5]=g_ams_status_heartbeat;
	send_frame(frame);
	// parse globals to according to protocol.
	// Insert passed two bytes into frm
	// Send byte

}




/*
 *  This function is a test of the Signal and message layer. It currently does not work
 */

void Send_Status_Message(){
    CANFRM      frm;
    CPU_INT16S  msg;
    CPU_INT08U  busId;

    busId = ZC7xxx_CAN_BUS_0;

    msg = CanMsgOpen(busId,0x122u,0);

    if(msg>=0) // The message could be found
    {
    	CanMsgRead(msg,&frm,sizeof(CANFRM)); // Create a canFrame based on the message and the linked signals.

    	CanBusWrite(busId,(void*)&frm,sizeof(CANFRM)); // Send Frame.

    }
    else
    {
    	if(msg == CAN_ERR_NULLMSG)
    	{
    		UCOS_Printf("\r\nHEEELP MSG ERROR \r\n");
    	}
    	else
    	{
    		UCOS_Printf("\r\nHEEELP \r\n");
    	}

    }




}
