/*
 * CAN_Rx_Task.c
 *
 *  Created on: Mar 18, 2020
 *      Author: soeren
 */

#include "CAN_Rx_Task.h"


void printCanMessage(CANFRM frame);
void decode_command_message(CANFRM * frame);

OS_ERR CAN_RX_createTask()
{
	OS_ERR err;

    OSTaskCreate(&CAN_RX_TCB,                      //  - RX Task.
                 "CAN RX Task",
				 CAN_RX_Task,
				 0,          				//argument for task. None for the moment
				 CAN_RX_TASK_PRIO,
				 &CAN_RxTaskStk[0],
				 CAN_RX_TASK_STK_SIZE/10,
				 CAN_RX_TASK_STK_SIZE,
				 CAN_RX_TASK_MSGQ_SIZE,
				 0,
				 DEF_NULL,
				 (OS_OPT_TASK_STK_CHK | OS_OPT_TASK_STK_CLR), //stack checking and stack clearing options
				 &err);

    return err;

}
void CAN_RX_Task(void *arg)
{
	CANFRM can_frm;
	CanBusIoCtl(ZC7xxx_CAN_BUS_0, CANBUS_SET_RX_TIMEOUT, 0u);   // Set Timeout to wait forever for new CAN Msg.

	UCOS_Printf("CAN_RX_TASK Started\n\r");
	while(1)
	{
		CanBusRead(ZC7xxx_CAN_BUS_0,
				(void *)&can_frm,
				sizeof(CANFRM)
				);
		// The task wake up here when a can frame has been recivced.

		if(can_frm.Identifier == COMMAND_CAN_MSG_ID)
		{
			decode_command_message(&can_frm);
			//command_signal = (can_frm.Data[0] & 7);
		}


		// END OF Messages

		if(true) //DEBUG_Setting_ON
		{
			printCanMessage(can_frm);
		}


	}


}
void decode_command_message(CANFRM * frame)
{
	command_signal = (frame->Data[0] & 7);
	g_bank_count_set_by_Car = ((frame->Data[0] & 0xE0) >>5);

}

void printCanMessage(CANFRM frame){
	// Print a CAn frame to the Seriel port.

	UCOS_Printf("CAN Message Recived: ID: %x  Data: %x %x %x %x %x %x %x %x \r\n",
			frame.Identifier,
			frame.Data[7],
			frame.Data[6],
			frame.Data[5],
			frame.Data[4],
			frame.Data[3],
			frame.Data[2],
			frame.Data[1],
			frame.Data[0]
					   );


}


/*
 * 	 CANFRM can_frm;
	 CanBusIoCtl(ZC7xxx_CAN_BUS_0, CANBUS_SET_RX_TIMEOUT, 0u);   // Set Timeout to wait forever for new CAN Msg.
	 int temp;
reset_flag = 0;

	 while (DEF_ON)
	 {
	     CanBusRead( ZC7xxx_CAN_BUS_0,                   // Pend till New CAN msg is found on CAN BUS
	                 (void *)&can_frm,
	                 sizeof(CANFRM));
	     if (debug_bool){UCOS_Print("Received something on CAN \n");}

	     switch (can_frm.Identifier)
	     {
	     case 0x401: //Master Command Message
	    	 OSMutexPend(&Controlvariable_Mutex, 0, OS_OPT_PEND_BLOCKING, 0, &CAN1_RX_ERR);
   		  	 if(CAN1_RX_ERR!= OS_ERR_NONE)
   		  	 {
   		  		 UCOS_Print("CAN rx, controlvariable mutex error\n");
   		  	 }

   		  	 //if((can_frm.Data[0]&0b1111)==1 ||(can_frm.Data[0]&0b1111)==1<<1||(can_frm.Data[0]&0b1111)==1<<2||(can_frm.Data[0]&0b1111)==1<<3||(can_frm.Data[0]&0b1111)==1<<4)
   		  	 // {rdy_flags |= can_frm.Data[0];}

   		  	 cmd_flags = can_frm.Data[0] &0b11111;

   		  	 if(can_frm.Data[0] & (1 << 5))
   		  		 reset_flag = 1;

   		  	 connected_to_charger = can_frm.Data[0] & (1 << 6);

   		  	 charging_scaler = can_frm.Data[1];



   		     OSMutexPost(&Controlvariable_Mutex, OS_OPT_POST_NONE, &CAN1_RX_ERR);
   		  	 if(CAN1_RX_ERR!= OS_ERR_NONE)
   		  	 {
   		  		 UCOS_Print("CAN rx, controlvariable mutex error\n");
   		  	 }
	     	 break;
 */
