/*
 * ChargingTask.c
 *
 *  Created on: 1. jul. 2019
 *      Author: matt
 */

#include "ChargingTask.h"

#include "os.h"
#include "xil_printf.h"
#include "stdint.h"
#include "common.h"
#include "dac.h"
#include "AMS_cfg.h"

void ChargingTask(void *arg)
{
	OS_ERR os_err;

	uint16_t lowest_cell_value;
	uint16_t highest_cell_value;

	//uint8_t charge_level = 0;

	while (1)
	{
		while (AMS_state != ChargeState)
		{
			dac_write(0);
			//dac_write(1023*charge_level/100);
			//charge_level += 1;
			//charge_level %= 101;
			balance_enable = false;
			charge_ready = false;
			charge_finished = false;
			//500 ms delay if not in charging state
			 OSTimeDly(500*OS_CFG_TICK_RATE_HZ/1000,
					   OS_OPT_TIME_PERIODIC,
					   &os_err);
		}

		OSMutexPend(&Voltage_Mutex,
				  0,
				  OS_OPT_PEND_BLOCKING,
				  0,
				  &os_err);
		if(os_err != OS_ERR_NONE)
			xil_printf("ChargingTask take voltage mutex error\r\n");


		lowest_cell_value = 9999;
		highest_cell_value = 0;

		for (uint8_t i = 0; i < bank_count; i++)
		{
			for (uint8_t j = 0; j < 28; j++)
			{
				if (cell_volt[i][j] < lowest_cell_value)
				{
					lowest_cell_value = cell_volt[i][j];
				}

				if (cell_volt[i][j] > highest_cell_value)
				{
					highest_cell_value = cell_volt[i][j];
				}
			}
		}

		OSMutexPend(&Controlvariable_Mutex,
				  0,
				  OS_OPT_PEND_BLOCKING,
				  0,
				  &os_err);
		if(os_err != OS_ERR_NONE)
			xil_printf("ChargingTask take controlvariable mutex error\r\n");

		if (highest_cell_value >= VOLT_CHARGE_LIMIT)
		{
			balance_enable = true;
		}

		if (highest_cell_value <= VOLT_CHARGE_GOAL + DISCHARGE_INTERVAL_MARGIN)
		{
			balance_enable = false;
		}

		if (lowest_cell_value >= VOLT_CHARGE_GOAL)
		{
			// Charging finished
			balance_enable = false;
			charge_finished = true;
		}

		if (balance_enable)
		{
			dac_write(0);
		}
		else
		{
			dac_write(1023*charging_scaler/100);
		}

		for (uint8_t i = 0; i < bank_count; i++)
		{
			for (uint8_t j = 0; j < 28; j++)
			{
				bal_enable[i][j] = false;
				//bal_enable[i][j] = balance_enable &&
				//		           (cell_volt[i][j] > lowest_cell_value + DISCHARGE_INTERVAL_MARGIN) &&
				//				   (bal_temp[i][j/2] < DISCHARGE_RESISTOR_TEMP_MAX);
			}
		}

		charge_ready = true;

		OSMutexPost(&Voltage_Mutex,
				  OS_OPT_PEND_BLOCKING,
				  &os_err);
		if(os_err != OS_ERR_NONE)
			xil_printf("ChargingTask give voltage mutex error\r\n");

		OSMutexPost(&Controlvariable_Mutex,
				  OS_OPT_PEND_BLOCKING,
				  &os_err);
		if(os_err != OS_ERR_NONE)
			xil_printf("ChargingTask give controlvariable mutex error\r\n");

		 OSTimeDly(CHARGINGTASK_LOOP_TIME_TICKS,
				   OS_OPT_TIME_PERIODIC,
				   &os_err);
		 if(os_err != OS_ERR_NONE)
		 	 xil_printf("ChargingTask delay error\r\n");
	}
}
