/*
 * SimulationTask.c
 *
 *  Created on: 5. jul. 2019
 *      Author: matt
 */

#include "AMS_cfg.h"
#include "common.h"
#include "os.h"
#include "xil_printf.h"

void SimulationTask(void *arg)
{
	OS_ERR os_err;

	while(1)
	{
		//xil_printf("%d | %d | %03d%%\r\n", balance_enable, charge_ready, charging_scaler);

		for (uint8_t i = 0; i < bank_count; i++)
		{
			for (uint8_t j = 0; j < 28; j++)
			{
				if (balance_enable)
				{
					if(bal_enable[i][j])
					{
						cell_volt[i][j] -= 1;
					}
				}
				else if (charge_ready)
				{
					cell_volt[i][j] += 5*charging_scaler/100;
				}
			}
		}

		OSTimeDly(200,
		          OS_OPT_TIME_PERIODIC,
		          &os_err);
		if(os_err != OS_ERR_NONE)
			xil_printf("SimulationTask delay error\r\n");
	}
}
