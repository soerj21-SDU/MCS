/*
 * PeripheralsTask.h
 *
 *  Created on: 7. maj 2019
 *      Author: matt
 */

#ifndef PERIPHERALSTASK_H_
#define PERIPHERALSTASK_H_

void PeripheralsTask(void *arg);

#endif /* PERIPHERALSTASK_H_ */
