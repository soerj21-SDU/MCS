/*
 * EnergymeterTask.h
 *
 *  Created on: 28. jun. 2019
 *      Author: M
 */

#ifndef SRC_ENERGYMETERTASK_H_
#define SRC_ENERGYMETERTASK_H_


/***************************** Include files *******************************/
#include "common.h"
/*****************************    Defines    *******************************/
#define  Energymeter_TASK_PRIO                         10u
#define  Energymeter_TASK_STK_SIZE                	       512u
#define  Energymeter_TASK_MSGQ_SIZE					   32u
/*****************************   Constants   *******************************/

OS_TCB Energymeter_TCB;
CPU_STK  EnergymeterTaskStk[Energymeter_TASK_STK_SIZE];
OS_ERR Energymeter_ERR;

/*****************************   Variables   *******************************/
/*****************************   Functions   *******************************/
void Energymeter_init();
//void EnergymeterTask(void* arg);
/****************************** End Of Module *******************************/
#endif /* SRC_ENERGYMETERTASK_H_ */
