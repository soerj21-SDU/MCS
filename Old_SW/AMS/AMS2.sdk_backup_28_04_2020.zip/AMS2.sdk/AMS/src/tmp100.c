/*
 * tmp100.c
 *
 *  Created on: 14. maj 2019
 *      Author: matt
 */

#include "tmp100.h"

#include "xparameters.h"
#include "xiicps.h"
#include "xil_printf.h"

XIicPs tmp100_iic;

void tmp100_init()
{
	XIicPs_Config *IicConfig;
		IicConfig = XIicPs_LookupConfig(XPAR_XIICPS_1_DEVICE_ID);
		if (NULL == IicConfig) {
			xil_printf("Lookup I2C config failed for TMP100\r\n");
		}

		int Status = XIicPs_CfgInitialize(&tmp100_iic, IicConfig,
				IicConfig->BaseAddress);
		if (Status != XST_SUCCESS) {
			xil_printf("Initialize I2C config failed for TMP100\r\n");
		}

		Status = XIicPs_SelfTest(&tmp100_iic);
		if (Status != XST_SUCCESS) {
			xil_printf("I2C self test failed for TMP100\r\n");
		}

		Status = XIicPs_SetOptions(&tmp100_iic, XIICPS_7_BIT_ADDR_OPTION
								         //| XIICPS_REP_START_OPTION
		);
			if (Status != XST_SUCCESS) {
				xil_printf("I2C set options failed for TMP100\r\n");
			}

		XIicPs_SetSClk(&tmp100_iic, 100000);
}

int16_t tmp100_read()
{
	uint8_t read_data[2] = {0x55, 0x55};

	XIicPs_MasterRecvPolled(&tmp100_iic, read_data, 2, 0x4E);

	int16_t tmp = (read_data[0]<<8) + read_data[1];

	return tmp;
}
