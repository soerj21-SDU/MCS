/*
 * ControlTask.h
 *
 *  Created on: 26. jun. 2019
 *      Author: matt
 */

#ifndef CONTROLTASK_H_
#define CONTROLTASK_H_

void ControlTask(void *arg);

#endif /* CONTROLTASK_H_ */
