# Zynq-Based Master Controller
This repository contains KiCAD files and documentation for the Zynq-based Master Controller meant to replace the X90-based one.

## Purpose
The Zynq-based Master Controller is meant to be lighter, more dynamic, and easier to approach than the previous one. It is based on the Xilinx Zynq-7020 placed on a PicoZed System-on-Module, which allows both dynamic FPGA configuration with Vivado and high-performance execution of C/C++ code in Vitis. The application code used on the Master Controller will be placed in the Master Controller Software repository.

Version 1 of the PCB has been designed as part of a bachelor project in late 2020. Documentation of the design is found in the repository and on Teams.

## Repository Structure
The repository, aside from this README file, also contains the file "Changes for next PCB". This includes all known flaws for the current PCB, which should be fixed in a new design. The following folders are also placed in the repository:

- Expansion-PCB
    - Contains the KiCad files for the ADC Expansion PCB to be placed on the Master Controller for additional functionality.
- ngspice simulation
    - Contains the KiCad schematics for ngspice simulations. ngspice is built into KiCad.
- PCB
    - Contains the KiCad files for the Master Controller PCB. Schematics are based around hierarchial sheets with interconnections.
- Test-PCB
    - Contains the KiCad files used to create a PCB for testing the PROFET functionalities.
- Documentation
    - Contains documentation for the Zynq Master Controller.

Remember to set-up the SDU-Vikings KiCad Library before adjusting these files, as you may otherwise get or generate errors.

## Design Overview
![System Overview](Documentation/SystemBlockDiagram.png)

## PCB Renders
![Master Controller PCB](Documentation/MasterController3D.png)

![ADC Expansion PCB](Documentation/Expansion3D.png)