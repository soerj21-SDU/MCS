#ifndef BRDK_STR_FUNCS
#define BRDK_STR_FUNCS 1

#include <brdkSTR.h>
#include <bur/plctypes.h>

#ifdef __cplusplus
	extern "C"
	{
#endif

#ifdef __cplusplus
	};
#endif

#endif
